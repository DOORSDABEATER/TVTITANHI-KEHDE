package dev.des.desecho.core.provider;

import java.net.URI;

/** A playable result. audioUrl equals videoUrl when the stream is combined; durationMs is -1 when unknown. */
public record ResolvedMedia(String title, long durationMs, boolean live, URI videoUrl, URI audioUrl, String provider) {}
