package dev.des.desecho.core.media;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * One managed ffmpeg process producing timestamped rgb24 frames into a bounded FrameQueue.
 * Never runs on the Minecraft main thread (it owns two daemon threads). close() always kills the process.
 */
public final class FfmpegVideoDecoder implements AutoCloseable {
    public enum End { EOF, ERROR, CLOSED }

    public interface Listener { void onEnd(End reason, String sanitizedMessage); }

    private final Process process;
    private final Thread reader;
    private final Thread errReader;
    private final StringBuilder errTail = new StringBuilder();
    private final int frameSize;
    private final int fps;
    private final long startMs;
    private final FrameQueue queue;
    private final boolean dropOldest;
    private final Listener listener;
    private volatile boolean closed;

    private FfmpegVideoDecoder(Process p, String name, int w, int h, int fps, long startMs,
                               FrameQueue q, boolean dropOldest, Listener l) {
        this.process = p;
        this.frameSize = w * h * 3;
        this.fps = fps;
        this.startMs = startMs;
        this.queue = q;
        this.dropOldest = dropOldest;
        this.listener = l;
        this.reader = new Thread(this::readFrames, "desecho-video-" + name);
        this.errReader = new Thread(this::drainStderr, "desecho-ffmpeg-err-" + name);
        reader.setDaemon(true);
        errReader.setDaemon(true);
    }

    public static FfmpegVideoDecoder start(String name, List<String> command, int w, int h, int fps, long startMs,
                                           FrameQueue queue, boolean dropOldest, Listener listener) throws IOException {
        Process p = new ProcessBuilder(command).start();
        p.getOutputStream().close();
        FfmpegVideoDecoder d = new FfmpegVideoDecoder(p, name, w, h, fps, startMs, queue, dropOldest, listener);
        d.errReader.start();
        d.reader.start();
        return d;
    }

    public boolean isAlive() { return process.isAlive(); }

    private void readFrames() {
        try (InputStream in = new BufferedInputStream(process.getInputStream(), 1 << 16)) {
            long idx = 0;
            while (!closed) {
                byte[] f = new byte[frameSize];
                if (!readFully(in, f)) break;
                queue.put(new Frame(idx, startMs + idx * 1000L / fps, f), dropOldest);
                idx++;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (IOException ignored) {
            // pipe closed by close() or the process died; handled below
        }
        End end;
        String msg = "";
        if (closed) {
            end = End.CLOSED;
        } else {
            int code = -1;
            try {
                if (process.waitFor(3, TimeUnit.SECONDS)) code = process.exitValue(); else process.destroyForcibly();
                errReader.join(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                process.destroyForcibly();
            }
            if (code == 0) {
                end = End.EOF;
            } else {
                end = End.ERROR;
                synchronized (errTail) { msg = ErrorSanitizer.sanitize(errTail.toString()); }
                if (msg.isEmpty()) msg = "The decoder stopped unexpectedly.";
            }
        }
        try { listener.onEnd(end, msg); } catch (Throwable ignored) { }
    }

    private static boolean readFully(InputStream in, byte[] buf) throws IOException {
        int off = 0;
        while (off < buf.length) {
            int n = in.read(buf, off, buf.length - off);
            if (n < 0) return false;
            off += n;
        }
        return true;
    }

    private void drainStderr() {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(process.getErrorStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                synchronized (errTail) {
                    errTail.append(line).append(' ');
                    if (errTail.length() > 2000) errTail.delete(0, errTail.length() - 2000);
                }
            }
        } catch (IOException ignored) { }
    }

    @Override
    public void close() {
        closed = true;
        process.destroy();
        try {
            if (!process.waitFor(2, TimeUnit.SECONDS)) process.destroyForcibly();
        } catch (InterruptedException e) {
            process.destroyForcibly();
            Thread.currentThread().interrupt();
        }
        reader.interrupt();
        try { reader.join(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
