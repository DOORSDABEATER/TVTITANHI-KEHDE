package dev.des.desecho.core.command;

import dev.des.desecho.core.display.DisplayDefinition;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Argument validation with player-facing messages (IllegalArgumentException.getMessage() is safe to show). */
public final class ArgParsers {
    private ArgParsers() {}

    private static final Pattern UNITS = Pattern.compile("(?:(\\d+)h)?(?:(\\d+)m)?(?:(\\d+(?:\\.\\d+)?)s)?");

    /** Accepts 90, 90.5, 1:30, 1:02:03, 1h2m3s, 2m, 45s. Returns milliseconds. */
    public static long parseTimeMs(String raw) {
        String s = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
        if (s.isEmpty()) throw bad();
        try {
            double seconds;
            if (s.contains(":")) {
                String[] p = s.split(":", -1);
                if (p.length < 2 || p.length > 3) throw bad();
                double total = 0;
                for (int i = 0; i < p.length; i++) {
                    if (p[i].isEmpty()) throw bad();
                    double v = Double.parseDouble(p[i]);
                    if (v < 0 || (i > 0 && v >= 60)) throw bad();
                    total = total * 60 + v;
                }
                seconds = total;
            } else if (s.matches("\\d+(\\.\\d+)?")) {
                seconds = Double.parseDouble(s);
            } else {
                Matcher m = UNITS.matcher(s);
                if (!m.matches() || (m.group(1) == null && m.group(2) == null && m.group(3) == null)) throw bad();
                seconds = (m.group(1) == null ? 0 : Long.parseLong(m.group(1)) * 3600)
                        + (m.group(2) == null ? 0 : Long.parseLong(m.group(2)) * 60)
                        + (m.group(3) == null ? 0 : Double.parseDouble(m.group(3)));
            }
            if (seconds > 7 * 24 * 3600) throw new IllegalArgumentException("That time is too large.");
            return Math.round(seconds * 1000);
        } catch (NumberFormatException e) {
            throw bad();
        }
    }

    private static IllegalArgumentException bad() {
        return new IllegalArgumentException("Time must look like 90, 1:30, 1:02:03 or 1h2m3s.");
    }

    public static int parseVolume(String raw) { return parseInt("Volume", raw, 0, 100); }

    public static int parseInt(String what, String raw, int min, int max) {
        try {
            int v = Integer.parseInt(raw.trim());
            if (v < min || v > max) throw new IllegalArgumentException(what + " must be between " + min + " and " + max + ".");
            return v;
        } catch (NumberFormatException | NullPointerException e) {
            throw new IllegalArgumentException(what + " must be a whole number between " + min + " and " + max + ".");
        }
    }

    public static double parseRange(String what, String raw, double max) {
        try {
            double v = Double.parseDouble(raw.trim());
            if (!(v > 0 && v <= max)) throw new IllegalArgumentException(what + " must be above 0 and at most " + (int) max + " blocks.");
            return v;
        } catch (NumberFormatException | NullPointerException e) {
            throw new IllegalArgumentException(what + " must be a number of blocks.");
        }
    }

    public static String parseScreenId(String raw) {
        String s = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
        if (!DisplayDefinition.ID_PATTERN.matcher(s).matches())
            throw new IllegalArgumentException("Screen ids use a-z, 0-9, '_' and '-' (max 32 characters).");
        return s;
    }

    public static DisplayDefinition.Facing parseFacing(String raw) {
        String s = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
        switch (s) {
            case "n": case "north": return DisplayDefinition.Facing.NORTH;
            case "s": case "south": return DisplayDefinition.Facing.SOUTH;
            case "e": case "east": return DisplayDefinition.Facing.EAST;
            case "w": case "west": return DisplayDefinition.Facing.WEST;
            default: throw new IllegalArgumentException("Facing must be north, south, east or west.");
        }
    }

    public static String formatTime(long ms) {
        long s = Math.max(0, ms) / 1000;
        return s >= 3600 ? String.format("%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60) : String.format("%d:%02d", s / 60, s % 60);
    }
}
