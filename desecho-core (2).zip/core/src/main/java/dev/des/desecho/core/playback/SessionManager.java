package dev.des.desecho.core.playback;

import dev.des.desecho.core.permission.AccessPolicy;
import dev.des.desecho.core.permission.Action;
import dev.des.desecho.core.permission.Actor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.LongSupplier;

/**
 * Owns every playback session, one per screen id, and enforces ownership on every operation.
 * All public methods are synchronized: operations are low-frequency control actions, never
 * per-frame work, so a single lock keeps the ownership rules race-free and simple.
 */
public final class SessionManager {
    public record Result(boolean ok, String message, PlaybackSession session) {
        static Result ok(String m, PlaybackSession s) { return new Result(true, m, s); }
        static Result fail(String m) { return new Result(false, m, null); }
    }

    public record Limits(int maxActiveSessions) {}

    private final Map<String, PlaybackSession> sessions = new HashMap<>();
    private final Limits limits;
    private final LongSupplier nanos;
    private final Consumer<String> audit;

    public SessionManager(Limits limits, LongSupplier nanos, Consumer<String> audit) {
        this.limits = limits;
        this.nanos = nanos;
        this.audit = audit;
    }

    public SessionManager(Limits limits, Consumer<String> audit) {
        this(limits, System::nanoTime, audit);
    }

    public synchronized Result play(Actor actor, String screenId, String source) {
        var d = AccessPolicy.check(actor, Action.PLAY, null);
        if (!d.allowed()) return Result.fail(d.reason());
        PlaybackSession existing = sessions.get(screenId);
        if (existing != null && existing.state() != SessionState.FAILED) {
            return Result.fail("That screen is already in use.");
        }
        long active = sessions.values().stream().filter(s -> s.state() != SessionState.FAILED).count();
        if (active >= limits.maxActiveSessions()) {
            return Result.fail("The server's limit on simultaneous videos has been reached.");
        }
        PlaybackSession s = new PlaybackSession(screenId, actor.id(), source, new PlaybackClock(nanos));
        sessions.put(screenId, s);
        return Result.ok("Loading...", s);
    }

    public synchronized Result stop(Actor actor, String screenId) {
        return control(actor, screenId, Action.STOP, this::remove);
    }

    public synchronized Result forceStop(Actor actor, String screenId) {
        return control(actor, screenId, Action.FORCE_STOP, this::remove);
    }

    public synchronized Result pause(Actor actor, String screenId) {
        return control(actor, screenId, Action.PAUSE, s -> {
            if (s.state() == SessionState.PAUSED) return Result.fail("Already paused.");
            if (s.state() != SessionState.PLAYING) return Result.fail("Playback hasn't started yet.");
            s.clock().pause();
            s.setState(SessionState.PAUSED);
            return Result.ok("Paused.", s);
        });
    }

    public synchronized Result resume(Actor actor, String screenId) {
        return control(actor, screenId, Action.RESUME, s -> {
            if (s.state() != SessionState.PAUSED) return Result.fail("Not paused.");
            s.clock().resume();
            s.setState(SessionState.PLAYING);
            return Result.ok("Resumed.", s);
        });
    }

    public synchronized Result seek(Actor actor, String screenId, long posMs) {
        return control(actor, screenId, Action.SEEK, s -> {
            if (posMs < 0) return Result.fail("Time can't be negative.");
            if (s.state() == SessionState.RESOLVING) return Result.fail("Still loading.");
            s.clock().seek(posMs);
            s.bumpSeekEpoch();
            return Result.ok("Seeked.", s);
        });
    }

    public synchronized Result setVolume(Actor actor, String screenId, int volume) {
        return control(actor, screenId, Action.VOLUME, s -> {
            if (volume < 0 || volume > 100) return Result.fail("Volume must be 0-100.");
            s.setVolume(volume);
            return Result.ok("Volume set to " + volume + ".", s);
        });
    }

    public synchronized Result toggleMute(Actor actor, String screenId) {
        return control(actor, screenId, Action.MUTE, s -> {
            s.setMuted(!s.muted());
            return Result.ok(s.muted() ? "Muted." : "Unmuted.", s);
        });
    }

    public synchronized Result transfer(Actor actor, String screenId, UUID newOwner, String newOwnerName) {
        return control(actor, screenId, Action.TRANSFER, s -> {
            UUID old = s.ownerId();
            s.setOwner(newOwner);
            audit.accept("TRANSFER screen=" + screenId + " from=" + old + " to=" + newOwner
                    + " (" + newOwnerName + ") by=" + describe(actor));
            return Result.ok("Ownership transferred.", s);
        });
    }

    public synchronized Optional<PlaybackSession> get(String screenId) {
        return Optional.ofNullable(sessions.get(screenId));
    }

    public synchronized List<PlaybackSession> all() {
        return new ArrayList<>(sessions.values());
    }

    /** Called by the media engine when the first frame is ready. Ignored if the session was stopped meanwhile. */
    public synchronized boolean markReady(PlaybackSession s, long startMs) {
        if (sessions.get(s.screenId()) != s || s.state() == SessionState.FAILED) return false;
        s.clock().start(startMs);
        s.setState(SessionState.PLAYING);
        return true;
    }

    public synchronized boolean markBuffering(PlaybackSession s) {
        if (sessions.get(s.screenId()) != s || s.state() != SessionState.RESOLVING) return false;
        s.setState(SessionState.BUFFERING);
        return true;
    }

    public synchronized boolean fail(PlaybackSession s, FailureStage stage, String sanitizedMessage) {
        if (sessions.get(s.screenId()) != s) return false;
        s.setFailure(stage, sanitizedMessage);
        return true;
    }

    /** Media finished naturally: removes the session (engine-internal, no permission check). Ignored if already replaced/stopped. */
    public synchronized boolean end(PlaybackSession s) {
        if (sessions.get(s.screenId()) != s) return false;
        sessions.remove(s.screenId());
        return true;
    }

    /** Shutdown/reload: drops every session and returns them so the caller can release their resources. */
    public synchronized List<PlaybackSession> stopAll(String reason) {
        List<PlaybackSession> out = new ArrayList<>(sessions.values());
        sessions.clear();
        audit.accept("STOP_ALL count=" + out.size() + " reason=" + reason);
        return out;
    }

    // ---- internals ----

    private Result remove(PlaybackSession s) {
        sessions.remove(s.screenId());
        return Result.ok("Stopped.", s);
    }

    private Result control(Actor actor, String screenId, Action action, Function<PlaybackSession, Result> op) {
        PlaybackSession s = sessions.get(screenId);
        if (s == null) return Result.fail("Nothing is playing on that screen.");
        var d = AccessPolicy.check(actor, action, s.ownerId());
        if (!d.allowed()) {
            audit.accept("DENIED action=" + action + " screen=" + screenId + " by=" + describe(actor));
            return Result.fail(d.reason());
        }
        Result r = op.apply(s);
        if (r.ok() && !s.ownerId().equals(actor.id()) && action != Action.TRANSFER) {
            audit.accept("ADMIN_OVERRIDE action=" + action + " screen=" + screenId
                    + " owner=" + s.ownerId() + " by=" + describe(actor));
        }
        return r;
    }

    private static String describe(Actor a) { return a.displayName() + " (" + a.id() + ")"; }
}
