package dev.des.desecho.core.provider;

import java.util.Locale;

/** Maps yt-dlp's stderr to a player-safe explanation. Raw tool output is never shown. */
public final class YtDlpErrors {
    private YtDlpErrors() {}

    public static String explain(String stderr) {
        String s = stderr == null ? "" : stderr.toLowerCase(Locale.ROOT);
        if (s.contains("private video")) return "That video is private.";
        if (s.contains("not a bot") || s.contains("confirm you")) return "The site is asking for bot verification, so the server can't fetch this video.";
        if (s.contains("sign in") || s.contains("log in") || s.contains("login") || s.contains("members-only") || s.contains("members only"))
            return "That video requires an account (login), which the server doesn't have.";
        if (s.contains("drm")) return "That video is DRM-protected and can't be played.";
        if (s.contains("geo") || s.contains("not available in your country") || s.contains("blocked it in your country"))
            return "That video is region-restricted.";
        if (s.contains("will begin in") || s.contains("premieres in") || s.contains("this live event"))
            return "That live stream or premiere hasn't started yet.";
        if (s.contains("video unavailable") || s.contains("has been removed") || s.contains("does not exist") || s.contains("no longer available"))
            return "That video is unavailable.";
        if (s.contains("http error 429") || s.contains("too many requests")) return "The site is rate-limiting the server; try again later.";
        if (s.contains("http error 403") || s.contains("forbidden")) return "The site refused the server's request (403).";
        if (s.contains("unsupported url")) return "That site isn't supported.";
        return "Could not extract a playable stream from that URL.";
    }
}
