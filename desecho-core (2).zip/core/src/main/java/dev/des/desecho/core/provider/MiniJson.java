package dev.des.desecho.core.provider;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Small strict JSON parser (no dependencies). Objects -> Map, arrays -> List, numbers -> Double. Depth-limited. */
public final class MiniJson {
    public static final class JsonException extends Exception {
        private static final long serialVersionUID = 1L;
        JsonException(String m) { super(m, null, false, false); }
    }

    private final String s;
    private int i;

    private MiniJson(String s) { this.s = s; }

    public static Object parse(String text) throws JsonException {
        MiniJson p = new MiniJson(text);
        p.ws();
        Object v = p.value(0);
        p.ws();
        if (p.i != p.s.length()) throw new JsonException("trailing data");
        return v;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> map(Object o) { return o instanceof Map ? (Map<String, Object>) o : null; }
    @SuppressWarnings("unchecked")
    public static List<Object> list(Object o) { return o instanceof List ? (List<Object>) o : null; }
    public static String str(Object o) { return o instanceof String ? (String) o : null; }

    private void ws() { while (i < s.length() && " \t\r\n".indexOf(s.charAt(i)) >= 0) i++; }

    private Object value(int depth) throws JsonException {
        if (depth > 64) throw new JsonException("too deep");
        if (i >= s.length()) throw new JsonException("unexpected end");
        char c = s.charAt(i);
        if (c == '{') return object(depth);
        if (c == '[') return array(depth);
        if (c == '"') return string();
        if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
        if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
        if (s.startsWith("null", i)) { i += 4; return null; }
        return number();
    }

    private Map<String, Object> object(int depth) throws JsonException {
        Map<String, Object> m = new LinkedHashMap<>();
        i++; ws();
        if (peek('}')) { i++; return m; }
        while (true) {
            ws();
            if (!peek('"')) throw new JsonException("expected key");
            String k = string();
            ws();
            if (!peek(':')) throw new JsonException("expected ':'");
            i++; ws();
            m.put(k, value(depth + 1));
            ws();
            if (peek(',')) { i++; continue; }
            if (peek('}')) { i++; return m; }
            throw new JsonException("expected ',' or '}'");
        }
    }

    private List<Object> array(int depth) throws JsonException {
        List<Object> l = new ArrayList<>();
        i++; ws();
        if (peek(']')) { i++; return l; }
        while (true) {
            ws();
            l.add(value(depth + 1));
            ws();
            if (peek(',')) { i++; continue; }
            if (peek(']')) { i++; return l; }
            throw new JsonException("expected ',' or ']'");
        }
    }

    private String string() throws JsonException {
        StringBuilder sb = new StringBuilder();
        i++;
        while (i < s.length()) {
            char c = s.charAt(i++);
            if (c == '"') return sb.toString();
            if (c < 0x20) throw new JsonException("control character in string");
            if (c != '\\') { sb.append(c); continue; }
            if (i >= s.length()) break;
            char e = s.charAt(i++);
            switch (e) {
                case '"': sb.append('"'); break;
                case '\\': sb.append('\\'); break;
                case '/': sb.append('/'); break;
                case 'b': sb.append('\b'); break;
                case 'f': sb.append('\f'); break;
                case 'n': sb.append('\n'); break;
                case 'r': sb.append('\r'); break;
                case 't': sb.append('\t'); break;
                case 'u':
                    if (i + 4 > s.length()) throw new JsonException("bad escape");
                    try { sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); } catch (NumberFormatException ex) { throw new JsonException("bad escape"); }
                    i += 4;
                    break;
                default: throw new JsonException("bad escape");
            }
        }
        throw new JsonException("unterminated string");
    }

    private Double number() throws JsonException {
        int st = i;
        while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
        if (st == i) throw new JsonException("unexpected character");
        try { return Double.valueOf(s.substring(st, i)); } catch (NumberFormatException e) { throw new JsonException("bad number"); }
    }

    private boolean peek(char c) { return i < s.length() && s.charAt(i) == c; }
}
