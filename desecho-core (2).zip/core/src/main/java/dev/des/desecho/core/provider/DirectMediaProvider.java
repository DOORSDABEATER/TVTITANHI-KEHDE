package dev.des.desecho.core.provider;

import dev.des.desecho.core.playback.FailureStage;
import dev.des.desecho.core.security.SecurityRejection;
import dev.des.desecho.core.security.UrlGuard;

import java.net.URI;
import java.util.Locale;
import java.util.Set;

/** URLs whose path ends in a known media/manifest extension are handed to ffmpeg as-is (no network I/O here). */
public final class DirectMediaProvider implements MediaProvider {
    public static final Set<String> DEFAULT_EXTENSIONS = Set.of("mp4", "webm", "mkv", "mov", "m4v", "m3u8", "mpd");
    private final UrlGuard guard;
    private final Set<String> extensions;

    public DirectMediaProvider(UrlGuard guard, Set<String> extensions) { this.guard = guard; this.extensions = Set.copyOf(extensions); }

    @Override public String name() { return "direct"; }

    @Override
    public boolean supports(URI uri) {
        String p = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
        int dot = p.lastIndexOf('.');
        return dot >= 0 && extensions.contains(p.substring(dot + 1));
    }

    @Override
    public ResolvedMedia resolve(URI uri) throws ResolveException {
        try {
            guard.validate(uri.toString());
        } catch (SecurityRejection e) {
            throw new ResolveException(FailureStage.SECURITY, e.getMessage());
        }
        String path = uri.getPath();
        String title = path.substring(path.lastIndexOf('/') + 1);
        return new ResolvedMedia(title.isEmpty() ? "video" : title, -1, false, uri, uri, name());
    }
}
