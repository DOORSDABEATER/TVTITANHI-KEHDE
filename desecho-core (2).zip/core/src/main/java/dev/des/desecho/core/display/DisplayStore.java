package dev.des.desecho.core.display;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

/** Persistence seam. FileDisplayStore ships now; a SQLite/SQL store can implement the same interface later. */
public interface DisplayStore {
    /** Loads every valid definition; unreadable entries are skipped and described (without paths) in warnings. */
    List<DisplayDefinition> load(List<String> warnings) throws IOException;
    /** Must be atomic: a crash mid-save may not corrupt the previous contents. */
    void save(Collection<DisplayDefinition> all) throws IOException;
}
