package dev.des.desecho.core.provider;

import java.net.URI;

/** Turns a (already UrlGuard-validated) URL into playable stream URLs. resolve() BLOCKS: never call it on the server thread. */
public interface MediaProvider {
    String name();
    boolean supports(URI uri);
    ResolvedMedia resolve(URI uri) throws ResolveException;
}
