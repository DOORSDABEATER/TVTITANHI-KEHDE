package dev.des.desecho.core.media;

/**
 * Decode targets from the spec. A map display is only cols*128 x rows*128 pixels, so the real
 * ceiling is the screen's pixel size and what the network can carry; presets only cap decode work.
 */
public enum QualityPreset {
    ECONOMY(854, 480, 15),
    BALANCED(1280, 720, 20),
    HIGH(1920, 1080, 20),
    ULTRA(2560, 1440, 30),
    EXPERIMENTAL(3840, 2160, 30);

    /** What to ask ffmpeg for, and how much to upscale when writing to the display. */
    public record CanvasPlan(int decodeW, int decodeH, int upscale, int fps) {}

    public final int maxW, maxH, fps;

    QualityPreset(int maxW, int maxH, int fps) { this.maxW = maxW; this.maxH = maxH; this.fps = fps; }

    public CanvasPlan plan(int displayW, int displayH, int adminMaxFps) {
        int k = 1;
        while (ceilDiv(displayW, k) > maxW || ceilDiv(displayH, k) > maxH) k++;
        return new CanvasPlan(ceilDiv(displayW, k), ceilDiv(displayH, k), k, Math.max(1, Math.min(fps, adminMaxFps)));
    }

    private static int ceilDiv(int a, int b) { return (a + b - 1) / b; }
}
