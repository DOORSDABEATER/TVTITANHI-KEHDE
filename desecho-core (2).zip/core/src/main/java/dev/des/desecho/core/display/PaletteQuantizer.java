package dev.des.desecho.core.display;

/**
 * RGB -> map palette index. The palette is NOT hard-coded: the Paper layer must build it at startup
 * from the server's own map palette (so it follows whatever the running version defines), and pass
 * it here as ARGB ints indexed by map color id. Indices below firstIndex (the transparent entries)
 * and fully transparent entries are never produced.
 * Uses a 32768-entry lookup (5 bits per channel) so per-pixel cost is a table read.
 */
public final class PaletteQuantizer {
    private final byte[] lut = new byte[32768];

    public PaletteQuantizer(int[] argbByIndex, int firstIndex) {
        int[] r = new int[argbByIndex.length], g = new int[argbByIndex.length], b = new int[argbByIndex.length];
        boolean[] usable = new boolean[argbByIndex.length];
        boolean any = false;
        for (int i = firstIndex; i < argbByIndex.length && i < 256; i++) {
            int c = argbByIndex[i];
            if ((c >>> 24) == 0) continue;
            usable[i] = true;
            any = true;
            r[i] = (c >> 16) & 0xff; g[i] = (c >> 8) & 0xff; b[i] = c & 0xff;
        }
        if (!any) throw new IllegalArgumentException("palette has no usable colors");
        for (int key = 0; key < 32768; key++) {
            int kr = ((key >> 10) & 31), kg = ((key >> 5) & 31), kb = key & 31;
            int pr = (kr << 3) | (kr >> 2), pg = (kg << 3) | (kg >> 2), pb = (kb << 3) | (kb >> 2);
            int best = -1;
            long bestD = Long.MAX_VALUE;
            for (int i = firstIndex; i < argbByIndex.length && i < 256; i++) {
                if (!usable[i]) continue;
                int rmean = (pr + r[i]) / 2;
                long dr = pr - r[i], dg = pg - g[i], db = pb - b[i];
                long d = (((512 + rmean) * dr * dr) >> 8) + 4 * dg * dg + (((767 - rmean) * db * db) >> 8);
                if (d < bestD) { bestD = d; best = i; }
            }
            lut[key] = (byte) best;
        }
    }

    public byte indexOf(int r, int g, int b) {
        return lut[((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3)];
    }

    /**
     * Converts an rgb24 frame into the display canvas, nearest-neighbour upscaling by an integer factor
     * (used when the quality preset decodes below the display's native pixel size).
     */
    public void blit(byte[] rgb, int srcW, int srcH, int upscale, byte[] dst, int dstW, int dstH) {
        int[] sx = new int[dstW];
        for (int x = 0; x < dstW; x++) sx[x] = Math.min(srcW - 1, x / upscale) * 3;
        for (int y = 0; y < dstH; y++) {
            int rowBase = Math.min(srcH - 1, y / upscale) * srcW * 3;
            int o = y * dstW;
            for (int x = 0; x < dstW; x++) {
                int i = rowBase + sx[x];
                dst[o + x] = lut[(((rgb[i] & 0xff) >> 3) << 10) | (((rgb[i + 1] & 0xff) >> 3) << 5) | ((rgb[i + 2] & 0xff) >> 3)];
            }
        }
    }
}
