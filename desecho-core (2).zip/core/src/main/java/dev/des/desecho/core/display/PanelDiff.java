package dev.des.desecho.core.display;

import java.util.ArrayList;
import java.util.List;

/**
 * Splits a canvas of palette indices (cols x rows maps of 128x128) into per-map partial updates,
 * sending only the bounding rectangle of what changed. Rect coordinates are relative to the map,
 * data is row-major (index = x + y * w), matching the map-data packet layout.
 */
public final class PanelDiff {
    public static final int PANEL = 128;

    public record Rect(int x, int y, int w, int h) {}
    public record Update(int col, int row, Rect rect, byte[] data) {}

    private PanelDiff() {}

    /** @param prev previous canvas, or null to force a full update of every map. */
    public static List<Update> diff(byte[] prev, byte[] next, int cols, int rows) {
        int width = cols * PANEL, height = rows * PANEL;
        if (next.length != width * height) throw new IllegalArgumentException("canvas size mismatch");
        if (prev != null && prev.length != next.length) throw new IllegalArgumentException("canvas size mismatch");
        List<Update> out = new ArrayList<>();
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int x0 = c * PANEL, y0 = r * PANEL;
                int minX = PANEL, minY = PANEL, maxX = -1, maxY = -1;
                if (prev == null) {
                    minX = 0; minY = 0; maxX = PANEL - 1; maxY = PANEL - 1;
                } else {
                    for (int y = 0; y < PANEL; y++) {
                        int base = (y0 + y) * width + x0;
                        for (int x = 0; x < PANEL; x++) {
                            if (prev[base + x] != next[base + x]) {
                                if (x < minX) minX = x;
                                if (x > maxX) maxX = x;
                                if (y < minY) minY = y;
                                maxY = y;
                            }
                        }
                    }
                }
                if (maxX < 0) continue;
                int w = maxX - minX + 1, h = maxY - minY + 1;
                byte[] data = new byte[w * h];
                for (int y = 0; y < h; y++) {
                    System.arraycopy(next, (y0 + minY + y) * width + x0 + minX, data, y * w, w);
                }
                out.add(new Update(c, r, new Rect(minX, minY, w, h), data));
            }
        }
        return out;
    }
}
