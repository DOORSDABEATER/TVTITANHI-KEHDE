package dev.des.desecho.core.provider;

import dev.des.desecho.core.playback.FailureStage;
import dev.des.desecho.core.security.SecurityRejection;
import dev.des.desecho.core.security.UrlGuard;

import java.net.URI;
import java.util.List;

/** Validates the URL, then asks the first provider that supports it. Order matters: put specific providers before the generic one. */
public final class SourceResolver {
    private final UrlGuard guard;
    private final List<MediaProvider> providers;

    public SourceResolver(UrlGuard guard, List<MediaProvider> providers) { this.guard = guard; this.providers = List.copyOf(providers); }

    /** BLOCKING. Call from an async worker. */
    public ResolvedMedia resolve(String rawUrl) throws ResolveException {
        URI uri;
        try {
            uri = guard.validate(rawUrl);
        } catch (SecurityRejection e) {
            throw new ResolveException(FailureStage.SECURITY, e.getMessage());
        }
        for (MediaProvider p : providers) if (p.supports(uri)) return p.resolve(uri);
        throw new ResolveException(FailureStage.EXTRACTION, "No provider can handle that kind of link.");
    }
}
