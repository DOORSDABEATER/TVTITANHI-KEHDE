package dev.des.desecho.core.media;

/** Strips URLs, filesystem paths and control characters from tool output before any player sees it. */
public final class ErrorSanitizer {
    private ErrorSanitizer() {}

    public static String sanitize(String raw) {
        if (raw == null) return "";
        String s = raw.replaceAll("https?://\\S+", "<url>")
                .replaceAll("\\b[A-Za-z]:\\\\\\S*", "<path>")
                .replaceAll("(?<![\\w<>])/(?:[\\w.@+~-]+/)*[\\w.@+~-]+", "<path>")
                .replaceAll("[\\p{Cntrl}]+", " ")
                .replaceAll("\\s{2,}", " ")
                .trim();
        return s.length() > 200 ? s.substring(0, 200) + "..." : s;
    }
}
