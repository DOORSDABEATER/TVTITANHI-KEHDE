package dev.des.desecho.core.security;

/** A request was refused for security reasons. The message is safe to show to players (no paths, no internals). */
public final class SecurityRejection extends Exception {
    private static final long serialVersionUID = 1L;
    public SecurityRejection(String message) { super(message, null, false, false); }
}
