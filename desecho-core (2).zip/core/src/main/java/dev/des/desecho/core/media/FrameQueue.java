package dev.des.desecho.core.media;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.atomic.AtomicLong;

/** Bounded frame buffer. Single producer (decoder thread), single consumer (presenter). */
public final class FrameQueue {
    private final ArrayBlockingQueue<Frame> q;
    private final AtomicLong dropped = new AtomicLong();

    public FrameQueue(int capacity) { q = new ArrayBlockingQueue<>(capacity); }

    /** dropOldest=true for live streams (never fall behind); false = block so a file decoder can't run ahead. */
    public void put(Frame f, boolean dropOldest) throws InterruptedException {
        if (dropOldest) {
            while (!q.offer(f)) { if (q.poll() != null) dropped.incrementAndGet(); }
        } else {
            q.put(f);
        }
    }

    public Frame peek() { return q.peek(); }
    public Frame poll() { return q.poll(); }
    public void clear() { q.clear(); }
    public int size() { return q.size(); }
    public long dropped() { return dropped.get(); }
}
