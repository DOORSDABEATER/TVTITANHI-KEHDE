package dev.des.desecho.core.display;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** All registered screens. Every mutation is persisted before it is visible; a failed save rolls the change back. */
public final class DisplayRegistry {
    public record Result(boolean ok, String message) {}

    private final Map<String, DisplayDefinition> map = new LinkedHashMap<>();
    private final DisplayStore store;
    private final List<String> loadWarnings = new ArrayList<>();

    public DisplayRegistry(DisplayStore store) throws IOException {
        this.store = store;
        for (DisplayDefinition d : store.load(loadWarnings)) map.put(d.id(), d);
    }

    public synchronized List<String> loadWarnings() { return List.copyOf(loadWarnings); }

    public synchronized Result add(DisplayDefinition d) {
        if (map.containsKey(d.id())) return new Result(false, "A screen named '" + d.id() + "' already exists.");
        for (DisplayDefinition o : map.values()) {
            if (DisplayGeometry.overlaps(o, d)) return new Result(false, "That would overlap the screen '" + o.id() + "'.");
        }
        map.put(d.id(), d);
        return persistOrRollback(() -> map.remove(d.id()), "Screen created.");
    }

    public synchronized Result update(DisplayDefinition d) {
        DisplayDefinition old = map.get(d.id());
        if (old == null) return new Result(false, "No screen named '" + d.id() + "'.");
        map.put(d.id(), d);
        return persistOrRollback(() -> map.put(old.id(), old), "Screen updated.");
    }

    public synchronized Result remove(String id) {
        DisplayDefinition old = map.remove(id);
        if (old == null) return new Result(false, "No screen named '" + id + "'.");
        return persistOrRollback(() -> map.put(old.id(), old), "Screen deleted.");
    }

    public synchronized Optional<DisplayDefinition> get(String id) { return Optional.ofNullable(map.get(id)); }

    public synchronized List<DisplayDefinition> list() {
        List<DisplayDefinition> l = new ArrayList<>(map.values());
        l.sort(Comparator.comparing(DisplayDefinition::id));
        return l;
    }

    private Result persistOrRollback(Runnable rollback, String okMsg) {
        try {
            store.save(map.values());
            return new Result(true, okMsg);
        } catch (IOException e) {
            rollback.run();
            return new Result(false, "Could not save the screen list; the change was not applied.");
        }
    }
}
