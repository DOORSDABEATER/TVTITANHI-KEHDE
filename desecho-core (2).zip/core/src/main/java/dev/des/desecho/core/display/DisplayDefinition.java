package dev.des.desecho.core.display;

import java.util.UUID;
import java.util.regex.Pattern;

/**
 * A registered screen. Pure data, no Bukkit types: world is the world UUID string, (x,y,z) is the
 * block of the panel at the viewer's bottom-left, facing is the direction the screen's face points
 * (towards its viewers).
 */
public record DisplayDefinition(String id, String world, int x, int y, int z, Facing facing, int cols, int rows,
                                double audioRange, double viewDistance, UUID createdBy) {
    public static final int PANEL_PIXELS = 128;
    public static final Pattern ID_PATTERN = Pattern.compile("[a-z0-9][a-z0-9_-]{0,31}");

    public enum Facing {
        NORTH(0, -1), SOUTH(0, 1), EAST(1, 0), WEST(-1, 0);
        public final int dx, dz;
        Facing(int dx, int dz) { this.dx = dx; this.dz = dz; }
        /** Viewer's right-hand direction when looking at the screen face. */
        public int rightX() { return dz; }
        public int rightZ() { return -dx; }
    }

    public DisplayDefinition {
        if (id == null || !ID_PATTERN.matcher(id).matches()) throw new IllegalArgumentException("Screen ids use a-z, 0-9, '_' and '-' (max 32 characters).");
        if (world == null || world.isBlank()) throw new IllegalArgumentException("A world is required.");
        if (facing == null) throw new IllegalArgumentException("A facing is required.");
        if (cols < 1 || cols > 64 || rows < 1 || rows > 64) throw new IllegalArgumentException("Screen size must be 1-64 panels in each direction.");
        if (!(audioRange > 0 && audioRange <= 512)) throw new IllegalArgumentException("Audio range must be between 0 and 512 blocks.");
        if (!(viewDistance > 0 && viewDistance <= 512)) throw new IllegalArgumentException("View distance must be between 0 and 512 blocks.");
        if (createdBy == null) throw new IllegalArgumentException("A creator is required.");
    }

    public int pixelWidth() { return cols * PANEL_PIXELS; }
    public int pixelHeight() { return rows * PANEL_PIXELS; }
    public DisplayDefinition withRanges(double audio, double view) { return new DisplayDefinition(id, world, x, y, z, facing, cols, rows, audio, view, createdBy); }
}
