package dev.des.desecho.core.display;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** One line per screen: id|world|x|y|z|FACING|cols|rows|audioRange|viewDistance|creatorUuid (world URL-encoded). Atomic write. */
public final class FileDisplayStore implements DisplayStore {
    private static final String HEADER = "# desecho-displays v1";
    private final Path file;

    public FileDisplayStore(Path file) { this.file = file; }

    @Override
    public List<DisplayDefinition> load(List<String> warnings) throws IOException {
        List<DisplayDefinition> out = new ArrayList<>();
        if (!Files.exists(file)) return out;
        Set<String> seen = new HashSet<>();
        int n = 0;
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
            n++;
            if (line.isBlank() || line.startsWith("#")) continue;
            try {
                String[] f = line.split("\\|", -1);
                if (f.length != 11) throw new IllegalArgumentException("wrong number of fields");
                DisplayDefinition d = new DisplayDefinition(f[0], URLDecoder.decode(f[1], StandardCharsets.UTF_8),
                        Integer.parseInt(f[2]), Integer.parseInt(f[3]), Integer.parseInt(f[4]),
                        DisplayDefinition.Facing.valueOf(f[5]), Integer.parseInt(f[6]), Integer.parseInt(f[7]),
                        Double.parseDouble(f[8]), Double.parseDouble(f[9]), UUID.fromString(f[10]));
                if (!seen.add(d.id())) throw new IllegalArgumentException("duplicate id");
                out.add(d);
            } catch (RuntimeException e) {
                warnings.add("displays file line " + n + " skipped: " + e.getMessage());
            }
        }
        return out;
    }

    @Override
    public void save(Collection<DisplayDefinition> all) throws IOException {
        StringBuilder sb = new StringBuilder(HEADER).append('\n');
        for (DisplayDefinition d : all) {
            sb.append(d.id()).append('|').append(URLEncoder.encode(d.world(), StandardCharsets.UTF_8)).append('|')
                    .append(d.x()).append('|').append(d.y()).append('|').append(d.z()).append('|').append(d.facing()).append('|')
                    .append(d.cols()).append('|').append(d.rows()).append('|').append(d.audioRange()).append('|')
                    .append(d.viewDistance()).append('|').append(d.createdBy()).append('\n');
        }
        Path parent = file.toAbsolutePath().getParent();
        Files.createDirectories(parent);
        Path tmp = Files.createTempFile(parent, "displays", ".tmp");
        try {
            Files.writeString(tmp, sb.toString(), StandardCharsets.UTF_8);
            Files.move(tmp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(tmp);
        }
    }
}
