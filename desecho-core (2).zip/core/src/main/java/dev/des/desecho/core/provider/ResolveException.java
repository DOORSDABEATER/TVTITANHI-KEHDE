package dev.des.desecho.core.provider;

import dev.des.desecho.core.playback.FailureStage;

/** Source could not be turned into a playable stream. getMessage() is safe to show to players. */
public final class ResolveException extends Exception {
    private static final long serialVersionUID = 1L;
    private final transient FailureStage stage;

    public ResolveException(FailureStage stage, String message) {
        super(message, null, false, false);
        this.stage = stage;
    }

    public FailureStage stage() { return stage; }
}
