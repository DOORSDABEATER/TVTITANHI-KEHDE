package dev.des.desecho.core.playback;

/** Which part of the pipeline failed, so players and admins get a useful explanation. */
public enum FailureStage { EXTRACTION, DECODING, AUDIO, DISPLAY, SECURITY, LIMIT }
