package dev.des.desecho.core.security;

import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.Locale;
import java.util.Set;

/**
 * SSRF guard for user-supplied URLs: http/https only, no credentials, allow-listed ports, and EVERY
 * resolved address must be public. Call validate() on the initial URL and again on every redirect hop
 * and every URL an extractor returns.
 *
 * Known limit: this is check-then-use. ffmpeg re-resolves the host itself, so a DNS-rebinding host can
 * still change answers between validation and connection. Closing that needs pinned-address fetching.
 */
public final class UrlGuard {
    @FunctionalInterface
    public interface Resolver { InetAddress[] resolve(String host) throws UnknownHostException; }

    private static final int MAX_LENGTH = 2048;
    private final Set<Integer> allowedPorts;
    private final Resolver resolver;

    public UrlGuard(Set<Integer> allowedPorts, Resolver resolver) {
        this.allowedPorts = Set.copyOf(allowedPorts);
        this.resolver = resolver;
    }

    public static UrlGuard systemDns(Set<Integer> allowedPorts) {
        return new UrlGuard(allowedPorts, InetAddress::getAllByName);
    }

    public URI validate(String raw) throws SecurityRejection {
        if (raw == null || raw.isBlank()) throw new SecurityRejection("No URL was provided.");
        String s = raw.trim();
        if (s.length() > MAX_LENGTH) throw new SecurityRejection("That URL is too long.");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c <= 0x20 || c == 0x7f) throw new SecurityRejection("The URL contains invalid characters.");
        }
        URI uri;
        try {
            uri = new URI(s);
        } catch (URISyntaxException e) {
            throw new SecurityRejection("That is not a valid URL.");
        }
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        if (!scheme.equals("http") && !scheme.equals("https")) {
            throw new SecurityRejection("Only http and https URLs are supported.");
        }
        if (uri.getRawUserInfo() != null) throw new SecurityRejection("URLs containing credentials are not allowed.");
        String host = uri.getHost();
        if (host == null || host.isEmpty()) throw new SecurityRejection("The URL has no valid host.");
        if (host.startsWith("[") && host.endsWith("]")) host = host.substring(1, host.length() - 1);
        int port = uri.getPort() == -1 ? (scheme.equals("https") ? 443 : 80) : uri.getPort();
        if (!allowedPorts.contains(port)) throw new SecurityRejection("That port is not allowed.");

        InetAddress[] addrs;
        try {
            addrs = resolver.resolve(host);
        } catch (UnknownHostException e) {
            throw new SecurityRejection("The host could not be resolved.");
        }
        if (addrs == null || addrs.length == 0) throw new SecurityRejection("The host could not be resolved.");
        for (InetAddress a : addrs) {
            if (!isPublic(a)) throw new SecurityRejection("That address is not allowed (private or internal network).");
        }
        return uri;
    }

    static boolean isPublic(InetAddress a) {
        if (a.isAnyLocalAddress() || a.isLoopbackAddress() || a.isLinkLocalAddress()
                || a.isSiteLocalAddress() || a.isMulticastAddress()) return false;
        byte[] b = a.getAddress();
        if (b.length == 4) return isPublicV4(b);
        if ((b[0] & 0xfe) == 0xfc) return false;                                           // fc00::/7 ULA
        if (b[0] == 0x20 && b[1] == 0x01 && b[2] == 0x0d && (b[3] & 0xff) == 0xb8) return false; // 2001:db8::/32
        if (b[0] == 0x20 && b[1] == 0x01 && b[2] == 0 && b[3] == 0) return false;          // Teredo
        if (b[0] == 0x20 && b[1] == 0x02) return isPublicV4(new byte[]{b[2], b[3], b[4], b[5]}); // 6to4
        if (b[0] == 0 && b[1] == 0x64 && (b[2] & 0xff) == 0xff && (b[3] & 0xff) == 0x9b && zero(b, 4, 12)) {
            return isPublicV4(new byte[]{b[12], b[13], b[14], b[15]});                      // NAT64
        }
        if (zero(b, 0, 12)) return isPublicV4(new byte[]{b[12], b[13], b[14], b[15]});     // ::a.b.c.d
        return true;
    }

    private static boolean isPublicV4(byte[] b) {
        int b0 = b[0] & 0xff, b1 = b[1] & 0xff, b2 = b[2] & 0xff;
        if (b0 == 0 || b0 == 10 || b0 == 127 || b0 >= 224) return false;
        if (b0 == 100 && (b1 & 0xc0) == 64) return false;          // 100.64.0.0/10 CGNAT
        if (b0 == 169 && b1 == 254) return false;                  // link-local / cloud metadata
        if (b0 == 172 && (b1 & 0xf0) == 16) return false;
        if (b0 == 192 && b1 == 168) return false;
        if (b0 == 192 && b1 == 0 && (b2 == 0 || b2 == 2)) return false;
        if (b0 == 198 && (b1 == 18 || b1 == 19)) return false;
        if (b0 == 198 && b1 == 51 && b2 == 100) return false;
        if (b0 == 203 && b1 == 0 && b2 == 113) return false;
        return true;
    }

    private static boolean zero(byte[] b, int from, int to) {
        for (int i = from; i < to; i++) if (b[i] != 0) return false;
        return true;
    }
}
