package dev.des.desecho.core.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Permission-aware tab completion for /desecho. Suggests only what the sender may actually use. */
public final class TabCompleter {
    private TabCompleter() {}

    public record Context(boolean canPlay, boolean canManageDisplays, boolean admin,
                          List<String> allScreens, List<String> freeScreens, List<String> controllableScreens,
                          List<String> playerNames) {}

    public static final List<String> PLAYER_CONTROLS = List.of("stop", "pause", "resume", "seek", "volume", "mute");

    public static List<String> complete(Context c, String[] args) {
        if (args.length == 0) return List.of();
        if (args.length == 1) {
            List<String> subs = new ArrayList<>(List.of("info", "screens"));
            if (c.canPlay() || c.admin()) { subs.add("play"); subs.addAll(PLAYER_CONTROLS); }
            if (c.canManageDisplays() || c.admin()) subs.addAll(List.of("create", "delete", "configure"));
            if (c.admin()) subs.addAll(List.of("force-stop", "transfer", "reload", "diagnostics", "status"));
            return filter(subs, args[0]);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        String cur = args[args.length - 1];
        boolean manage = c.canManageDisplays() || c.admin();
        if (args.length == 2) {
            switch (sub) {
                case "play": return (c.canPlay() || c.admin()) ? filter(c.freeScreens(), cur) : List.of();
                case "stop": case "pause": case "resume": case "seek": case "volume": case "mute":
                    return (c.canPlay() || c.admin()) ? filter(c.controllableScreens(), cur) : List.of();
                case "info": return filter(c.allScreens(), cur);
                case "delete": case "configure": return manage ? filter(c.allScreens(), cur) : List.of();
                case "force-stop": case "transfer": return c.admin() ? filter(c.allScreens(), cur) : List.of();
                default: return List.of();
            }
        }
        if (args.length == 3) {
            switch (sub) {
                case "seek": return filter(List.of("0:00", "0:30", "1:00", "5:00"), cur);
                case "volume": return filter(List.of("0", "25", "50", "75", "100"), cur);
                case "create": return manage ? filter(List.of("4", "8", "16"), cur) : List.of();
                case "transfer": return c.admin() ? filter(c.playerNames(), cur) : List.of();
                case "configure": return manage ? filter(List.of("audio-range", "view-distance"), cur) : List.of();
                default: return List.of();
            }
        }
        if (args.length == 4 && sub.equals("create") && manage) return filter(List.of("2", "3", "4", "9"), cur);
        if (args.length == 5 && sub.equals("create") && manage) return filter(List.of("north", "south", "east", "west"), cur);
        return List.of();
    }

    private static List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : options) if (o.toLowerCase(Locale.ROOT).startsWith(p)) out.add(o);
        return out;
    }
}
