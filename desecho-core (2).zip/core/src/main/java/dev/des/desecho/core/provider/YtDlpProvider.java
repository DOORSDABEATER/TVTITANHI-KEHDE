package dev.des.desecho.core.provider;

import dev.des.desecho.core.media.ErrorSanitizer;
import dev.des.desecho.core.playback.FailureStage;
import dev.des.desecho.core.security.SecurityRejection;
import dev.des.desecho.core.security.UrlGuard;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Site extraction through an external yt-dlp binary (argument list only, never a shell). One class serves
 * YouTube/Twitch/Vimeo (host-matched, so messages can name the site) and a generic fallback (empty host set).
 * Every URL yt-dlp returns is re-checked with UrlGuard. Output size and run time are bounded; the process is killed on timeout.
 */
public final class YtDlpProvider implements MediaProvider {
    private static final int MAX_STDOUT = 1 << 20;

    private final String name;
    private final Set<String> hostSuffixes;
    private final String binary;
    private final UrlGuard guard;
    private final long timeoutMs;
    private final int maxHeight;

    public YtDlpProvider(String name, Set<String> hostSuffixes, String binary, UrlGuard guard, long timeoutMs, int maxHeight) {
        this.name = name; this.hostSuffixes = Set.copyOf(hostSuffixes); this.binary = binary;
        this.guard = guard; this.timeoutMs = timeoutMs; this.maxHeight = maxHeight;
    }

    @Override public String name() { return name; }

    @Override
    public boolean supports(URI uri) {
        if (hostSuffixes.isEmpty()) return true; // generic fallback
        String h = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
        for (String suf : hostSuffixes) if (h.equals(suf) || h.endsWith("." + suf)) return true;
        return false;
    }

    List<String> command(URI uri) {
        List<String> c = new ArrayList<>(List.of(binary, "--ignore-config", "--no-playlist", "--no-warnings", "--no-cache-dir",
                "--socket-timeout", "15", "--dump-single-json", "-f",
                "bv*[height<=" + maxHeight + "]+ba/b[height<=" + maxHeight + "]/b"));
        c.add("--");
        c.add(uri.toString());
        return c;
    }

    @Override
    public ResolvedMedia resolve(URI uri) throws ResolveException {
        Process p;
        try {
            p = new ProcessBuilder(command(uri)).start();
        } catch (IOException e) {
            throw new ResolveException(FailureStage.EXTRACTION, "This link needs yt-dlp, which is not installed on the server.");
        }
        try { p.getOutputStream().close(); } catch (IOException ignored) { }
        AtomicBoolean tooBig = new AtomicBoolean();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        StringBuilder err = new StringBuilder();
        Thread to = new Thread(() -> pump(p.getInputStream(), out, MAX_STDOUT, tooBig, p), "desecho-ytdlp-out");
        Thread te = new Thread(() -> { ByteArrayOutputStream e = new ByteArrayOutputStream(); pump(p.getErrorStream(), e, 8000, new AtomicBoolean(), null);
            synchronized (err) { err.append(e.toString(StandardCharsets.UTF_8)); } }, "desecho-ytdlp-err");
        to.setDaemon(true); te.setDaemon(true);
        to.start(); te.start();
        boolean done;
        try {
            done = p.waitFor(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            p.destroyForcibly();
            Thread.currentThread().interrupt();
            throw new ResolveException(FailureStage.EXTRACTION, "Extraction was cancelled.");
        }
        if (!done) {
            p.destroyForcibly();
            throw new ResolveException(FailureStage.EXTRACTION, "Looking up that link took too long and was cancelled.");
        }
        try { to.join(2000); te.join(2000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        if (tooBig.get()) throw new ResolveException(FailureStage.EXTRACTION, "The site returned too much data.");
        if (p.exitValue() != 0) {
            String text; synchronized (err) { text = err.toString(); }
            throw new ResolveException(FailureStage.EXTRACTION, YtDlpErrors.explain(text));
        }
        return parse(out.toString(StandardCharsets.UTF_8));
    }

    private static void pump(InputStream in, ByteArrayOutputStream sink, int cap, AtomicBoolean overflow, Process killOnOverflow) {
        byte[] buf = new byte[8192];
        try {
            int n;
            while ((n = in.read(buf)) >= 0) {
                if (sink.size() + n > cap) {
                    overflow.set(true);
                    if (killOnOverflow != null) killOnOverflow.destroyForcibly();
                    return;
                }
                sink.write(buf, 0, n);
            }
        } catch (IOException ignored) { }
    }

    ResolvedMedia parse(String json) throws ResolveException {
        Map<String, Object> root;
        try {
            root = MiniJson.map(MiniJson.parse(json));
        } catch (MiniJson.JsonException e) {
            root = null;
        }
        if (root == null) throw new ResolveException(FailureStage.EXTRACTION, "The extractor returned something unreadable.");
        String video = null, audio = null;
        List<Object> formats = MiniJson.list(root.get("requested_formats"));
        if (formats != null && !formats.isEmpty()) {
            for (Object o : formats) {
                Map<String, Object> f = MiniJson.map(o);
                if (f == null || MiniJson.str(f.get("url")) == null) continue;
                boolean hasV = !"none".equals(MiniJson.str(f.get("vcodec"))), hasA = !"none".equals(MiniJson.str(f.get("acodec")));
                String u = MiniJson.str(f.get("url"));
                if (hasV && video == null) video = u;
                if (hasA && !hasV && audio == null) audio = u;
                if (hasV && hasA && audio == null) audio = u;
            }
        }
        if (video == null) {
            video = MiniJson.str(root.get("url"));
            audio = video;
        }
        if (video == null) throw new ResolveException(FailureStage.EXTRACTION, "No playable video stream was found.");
        if (audio == null) audio = video;
        URI v, a;
        try {
            v = guard.validate(video);
            a = audio.equals(video) ? v : guard.validate(audio);
        } catch (SecurityRejection e) {
            throw new ResolveException(FailureStage.SECURITY, "The extractor pointed at an address that isn't allowed.");
        }
        String title = MiniJson.str(root.get("title"));
        title = title == null ? "video" : ErrorSanitizer.sanitize(title);
        Object d = root.get("duration");
        long dur = d instanceof Double ? Math.round((Double) d * 1000) : -1;
        boolean live = Boolean.TRUE.equals(root.get("is_live"));
        return new ResolvedMedia(title, live ? -1 : dur, live, v, a, name);
    }
}
