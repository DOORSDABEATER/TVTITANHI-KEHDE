package dev.des.desecho.core.display;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** World-space layout of a screen's panels. Column 0 is the viewer's left, row 0 is the top. */
public final class DisplayGeometry {
    private DisplayGeometry() {}

    public record Panel(int col, int row, int x, int y, int z) {}

    public static List<Panel> panels(DisplayDefinition d) {
        List<Panel> out = new ArrayList<>(d.cols() * d.rows());
        int rx = d.facing().rightX(), rz = d.facing().rightZ();
        for (int row = 0; row < d.rows(); row++) {
            for (int col = 0; col < d.cols(); col++) {
                out.add(new Panel(col, row, d.x() + rx * col, d.y() + (d.rows() - 1 - row), d.z() + rz * col));
            }
        }
        return out;
    }

    /** Centre of the screen surface in block coordinates (used for audio origin and view distance). */
    public static double[] center(DisplayDefinition d) {
        double rx = d.facing().rightX(), rz = d.facing().rightZ();
        double cx = d.x() + 0.5 + rx * (d.cols() - 1) / 2.0;
        double cz = d.z() + 0.5 + rz * (d.cols() - 1) / 2.0;
        double cy = d.y() + 0.5 + (d.rows() - 1) / 2.0;
        return new double[]{cx, cy, cz};
    }

    public static boolean overlaps(DisplayDefinition a, DisplayDefinition b) {
        if (!a.world().equals(b.world())) return false;
        Set<Long> cells = new HashSet<>();
        for (Panel p : panels(a)) cells.add(key(p));
        for (Panel p : panels(b)) if (cells.contains(key(p))) return true;
        return false;
    }

    private static long key(Panel p) { return (((long) p.x() & 0x3FFFFFFL) << 38) | (((long) p.z() & 0x3FFFFFFL) << 12) | ((long) p.y() & 0xFFFL); }

    public static double distanceToCenter(DisplayDefinition d, double px, double py, double pz) {
        double[] c = center(d);
        double dx = px - c[0], dy = py - c[1], dz = pz - c[2];
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
