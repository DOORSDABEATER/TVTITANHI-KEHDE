package dev.des.desecho.core;

import dev.des.desecho.core.display.PaletteQuantizer;
import dev.des.desecho.core.engine.*;
import dev.des.desecho.core.media.FfmpegCommands;
import dev.des.desecho.core.media.QualityPreset;
import dev.des.desecho.core.permission.Actor;
import dev.des.desecho.core.playback.*;
import dev.des.desecho.core.security.LocalMediaPolicy;

import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.BooleanSupplier;

/** Engine integration tests: real ffmpeg processes, real threads, fake display/audio sinks. No Minecraft involved. */
public final class IntegrationTests {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS  " : "FAIL  ") + n); }

    static final UUID ALICE = new UUID(0, 0xa11ce), BOB = new UUID(0, 0xb0b);
    static Actor alice() { return new Actor(ALICE, "Alice", true, false, false); }
    static Actor bob() { return new Actor(BOB, "Bob", true, false, false); }
    static final int RED = 6, BLUE = 8, W = 256, H = 144;

    static Path media;
    static LocalMediaPolicy policy;

    static final class Sink implements DisplaySink {
        final AtomicInteger presents = new AtomicInteger();
        volatile int center = -1;
        volatile boolean cleared;
        public void present(byte[] c) { center = c[(H / 2) * W + W / 2]; presents.incrementAndGet(); }
        public void clear() { cleared = true; }
    }

    static boolean until(BooleanSupplier c, long ms) throws InterruptedException {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) { if (c.getAsBoolean()) return true; Thread.sleep(25); }
        return c.getAsBoolean();
    }

    static PaletteQuantizer palette() {
        int[] p = new int[256];
        p[4] = 0xFF000000; p[5] = 0xFFFFFFFF; p[6] = 0xFFFF0000; p[7] = 0xFF00FF00; p[8] = 0xFF0000FF;
        return new PaletteQuantizer(p, 4);
    }

    static void sh(String... cmd) throws Exception {
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        String o = new String(p.getInputStream().readAllBytes());
        if (p.waitFor() != 0) throw new IllegalStateException(o);
    }

    static FfmpegCommands.Source src(String name) throws Exception {
        return new FfmpegCommands.Source(policy.resolve(name).toString(), true);
    }

    static ScreenPlayer.Config cfg(long idleMs) {
        return new ScreenPlayer.Config("ffmpeg", W, H, QualityPreset.BALANCED.plan(W, H, 10), 600, 16, idleMs);
    }

    public static void main(String[] a) throws Exception {
        Path dir = Files.createTempDirectory("desecho-it");
        media = Files.createDirectory(dir.resolve("media"));
        policy = new LocalMediaPolicy(List.of(media), Set.of("mp4"));
        String rb = "color=c=red:s=256x144:r=25:d=%d", bl = "color=c=blue:s=256x144:r=25:d=%d";
        sh("ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", String.format(rb, 6), "-f", "lavfi", "-i", String.format(bl, 6),
                "-f", "lavfi", "-i", "sine=frequency=440:duration=12", "-filter_complex", "[0:v][1:v]concat=n=2:v=1:a=0[v]",
                "-map", "[v]", "-map", "2:a", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", "-c:a", "aac", media.resolve("rb.mp4").toString());
        sh("ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", String.format(rb, 2), "-f", "lavfi", "-i", "sine=frequency=440:duration=2",
                "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", "-c:a", "aac", media.resolve("short.mp4").toString());
        sh("ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", String.format(rb, 6), "-an", "-c:v", "libx264", "-preset", "ultrafast",
                "-pix_fmt", "yuv420p", media.resolve("silent.mp4").toString());
        Files.writeString(media.resolve("bad.mp4"), "not a video");

        video(dir);
        videoLifecycle(dir);
        audio(dir);

        Thread.sleep(300);
        boolean leakedThreads = Thread.getAllStackTraces().keySet().stream().anyMatch(t -> t.isAlive() && t.getName().startsWith("desecho-"));
        check("no desecho threads left alive after all scenarios", !leakedThreads);
        long ff = ProcessHandle.current().descendants().filter(ProcessHandle::isAlive)
                .filter(h -> h.info().command().orElse("").contains("ffmpeg")).count();
        check("no ffmpeg processes left alive after all scenarios", ff == 0);
        System.out.println("\n" + pass + " passed, " + fail + " failed (integration)");
        System.exit(fail == 0 ? 0 : 1);
    }

    static void video(Path dir) throws Exception {
        var m = new SessionManager(new SessionManager.Limits(4), x -> { });
        var s = m.play(alice(), "lobby", "rb.mp4").session();
        var sink = new Sink();
        var viewers = new AtomicBoolean(true);
        var p = new ScreenPlayer(m, s, src("rb.mp4"), cfg(300), palette(), sink, viewers::get);
        p.start();
        check("video: session reaches PLAYING once the first frame is decoded", until(() -> s.state() == SessionState.PLAYING, 10_000));
        int c0 = sink.presents.get();
        Thread.sleep(2000);
        int n = sink.presents.get() - c0;
        long pos = s.clock().positionMs();
        check("video: ~10 fps presented over 2 s (got " + n + ")", n >= 14 && n <= 22);
        check("video: clock advanced ~2 s (pos " + pos + ")", pos >= 1900 && pos <= 3500);
        check("video: first segment shows red", sink.center == RED);

        check("video: non-owner cannot pause (picture keeps running)", !m.pause(bob(), "lobby").ok());
        m.pause(alice(), "lobby");
        Thread.sleep(250);
        int frozen = sink.presents.get();
        long posP = s.clock().positionMs();
        Thread.sleep(700);
        check("video: pause freezes picture", sink.presents.get() - frozen <= 1);
        check("video: pause freezes clock", s.clock().positionMs() == posP);
        m.resume(alice(), "lobby");
        int before = sink.presents.get();
        Thread.sleep(700);
        check("video: resume continues picture", sink.presents.get() - before >= 4);

        m.seek(alice(), "lobby", 8000);
        check("video: seek forward switches to the blue segment", until(() -> sink.center == BLUE, 6000));
        check("video: clock is at/after the seek target", s.clock().positionMs() >= 8000);
        m.seek(alice(), "lobby", 1000);
        check("video: seek backward returns to red", until(() -> sink.center == RED, 6000));

        m.stop(alice(), "lobby");
        check("video: stop by owner ends presenter thread", until(() -> !p.isRunning(), 3000));
        check("video: stop kills the ffmpeg process", !p.isDecoding());
        check("video: stop clears the display", sink.cleared);
        p.close();

        // viewers leave -> decoder stops; seek while empty; viewers return -> resync to the clock position
        var m2 = new SessionManager(new SessionManager.Limits(4), x -> { });
        var s2 = m2.play(alice(), "lobby", "rb.mp4").session();
        var sink2 = new Sink();
        var v2 = new AtomicBoolean(true);
        var p2 = new ScreenPlayer(m2, s2, src("rb.mp4"), cfg(300), palette(), sink2, v2::get);
        p2.start();
        until(() -> s2.state() == SessionState.PLAYING, 10_000);
        v2.set(false);
        check("viewers: decoder stops after the idle grace period", until(() -> !p2.isDecoding(), 3000));
        m2.seek(alice(), "lobby", 8000);
        Thread.sleep(600);
        check("viewers: seek with nobody watching does not spawn a decoder", !p2.isDecoding());
        v2.set(true);
        check("viewers: returning viewer restarts decoding", until(p2::isDecoding, 3000));
        check("viewers: returning viewer is resynchronised to the clock (blue segment)", until(() -> sink2.center == BLUE, 6000));
        p2.close();
    }

    static void videoLifecycle(Path dir) throws Exception {
        var m = new SessionManager(new SessionManager.Limits(4), x -> { });
        var s = m.play(alice(), "s", "short.mp4").session();
        var p = new ScreenPlayer(m, s, src("short.mp4"), cfg(300), palette(), new Sink(), () -> true);
        p.start();
        check("lifecycle: natural end removes the session", until(() -> m.get("s").isEmpty(), 10_000));
        check("lifecycle: presenter exits after natural end", until(() -> !p.isRunning(), 3000));

        var m2 = new SessionManager(new SessionManager.Limits(4), x -> { });
        var s2 = m2.play(alice(), "s", "bad.mp4").session();
        var p2 = new ScreenPlayer(m2, s2, src("bad.mp4"), cfg(300), palette(), new Sink(), () -> true);
        p2.start();
        check("lifecycle: undecodable file -> session FAILED at DECODING", until(() -> s2.state() == SessionState.FAILED, 10_000)
                && s2.failureStage() == FailureStage.DECODING);
        check("lifecycle: failure message has no filesystem path", s2.failureMessage() != null && !s2.failureMessage().contains(dir.toString()));
        check("lifecycle: presenter exits after failure", until(() -> !p2.isRunning(), 3000));

        // two independent screens; one failing does not disturb the other
        var m3 = new SessionManager(new SessionManager.Limits(4), x -> { });
        var good = m3.play(alice(), "good", "rb.mp4").session();
        var broken = m3.play(bob(), "broken", "bad.mp4").session();
        var gs = new Sink();
        var pg = new ScreenPlayer(m3, good, src("rb.mp4"), cfg(300), palette(), gs, () -> true);
        var pb = new ScreenPlayer(m3, broken, src("bad.mp4"), cfg(300), palette(), new Sink(), () -> true);
        pg.start(); pb.start();
        check("isolation: broken screen fails", until(() -> broken.state() == SessionState.FAILED, 10_000));
        check("isolation: good screen still plays", until(() -> good.state() == SessionState.PLAYING, 10_000) && until(() -> gs.center == RED, 3000));
        pg.close(); pb.close();
        check("shutdown: stopAll + close leaves no running players", m3.stopAll("test").size() == 2 && !pg.isRunning() && !pg.isDecoding());
    }

    static void audio(Path dir) throws Exception {
        var m = new SessionManager(new SessionManager.Limits(4), x -> { });
        var s = m.play(alice(), "a", "rb.mp4").session();
        m.markReady(s, 0);
        long t0 = System.nanoTime();
        List<Long> arrivals = Collections.synchronizedList(new ArrayList<>());
        AtomicInteger badSize = new AtomicInteger();
        var errors = new CopyOnWriteArrayList<String>();
        var f = new AudioFeeder(m, s, src("rb.mp4"), "ffmpeg", 600, 300, fr -> {
            if (fr.length != AudioFeeder.FRAME_BYTES) badSize.incrementAndGet();
            arrivals.add(System.nanoTime());
        }, () -> true, errors::add);
        f.start();
        Thread.sleep(2600);
        int n = arrivals.size();
        check("audio: ~20 ms frames paced in real time (got " + n + " in 2.6 s)", n >= 95 && n <= 125);
        check("audio: every frame is exactly 1920 bytes", badSize.get() == 0 && n > 0);
        double maxDev = 0;
        for (int i = 0; i < n; i++) maxDev = Math.max(maxDev, Math.abs((arrivals.get(i) - arrivals.get(0)) / 1e6 - i * 20.0));
        check("audio: steady pacing, no bursts (max deviation " + (int) maxDev + " ms)", maxDev < 80);
        check("audio: first frame waits for start-up allowance, not delivered instantly", (arrivals.get(0) - t0) / 1e6 > 200);

        m.pause(alice(), "a");
        Thread.sleep(150);
        int c1 = arrivals.size();
        Thread.sleep(600);
        check("audio: pause stops delivery", arrivals.size() - c1 <= 1);
        m.resume(alice(), "a");
        Thread.sleep(500);
        check("audio: resume restarts delivery", arrivals.size() - c1 >= 15);

        long r0 = f.restarts();
        m.seek(alice(), "a", 5000);
        check("audio: seek restarts ffmpeg at the new clock position", until(() -> f.restarts() == r0 + 1, 2000)
                && Math.abs(f.lastBaseMs() - 5300) < 200);
        int c2 = arrivals.size();
        Thread.sleep(800);
        check("audio: delivery continues after seek", arrivals.size() - c2 >= 20);
        check("audio: no error reported on a good file", errors.isEmpty());
        f.close();
        check("audio: close() kills ffmpeg and ends the thread", !f.isRunning() && !f.isDecoding());

        // no audio track -> surfaced, not silent
        var m2 = new SessionManager(new SessionManager.Limits(4), x -> { });
        var s2 = m2.play(alice(), "q", "silent.mp4").session();
        m2.markReady(s2, 0);
        var errs2 = new CopyOnWriteArrayList<String>();
        var f2 = new AudioFeeder(m2, s2, src("silent.mp4"), "ffmpeg", 600, 300, fr -> { }, () -> true, errs2::add);
        f2.start();
        check("audio: file without an audio track reports an error (no silent failure)", until(() -> !errs2.isEmpty(), 8000));
        check("audio: that error text has no filesystem path", !errs2.isEmpty() && !errs2.get(0).contains(dir.toString()));
        f2.close();

        // listeners leave -> ffmpeg stops; return -> resumes at clock position
        var m3 = new SessionManager(new SessionManager.Limits(4), x -> { });
        var s3 = m3.play(alice(), "l", "rb.mp4").session();
        m3.markReady(s3, 0);
        var near = new AtomicBoolean(true);
        var f3 = new AudioFeeder(m3, s3, src("rb.mp4"), "ffmpeg", 600, 300, fr -> { }, near::get, x -> { });
        f3.start();
        until(() -> f3.delivered() > 5, 5000);
        near.set(false);
        check("audio: ffmpeg stops when nobody is in range", until(() -> !f3.isDecoding(), 3000));
        near.set(true);
        long d = f3.delivered();
        check("audio: returning listener gets audio again", until(() -> f3.delivered() > d + 5, 5000));
        f3.close();
    }
}
