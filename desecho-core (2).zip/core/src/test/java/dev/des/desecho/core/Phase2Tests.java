package dev.des.desecho.core;

import dev.des.desecho.core.command.*;
import dev.des.desecho.core.display.*;
import dev.des.desecho.core.display.DisplayDefinition.Facing;
import dev.des.desecho.core.playback.FailureStage;
import dev.des.desecho.core.provider.*;
import dev.des.desecho.core.security.UrlGuard;

import java.net.InetAddress;
import java.net.URI;
import java.net.UnknownHostException;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.*;

/** Registry, geometry, persistence, argument parsing, tab completion and provider tests. No Minecraft, no network. */
public final class Phase2Tests {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS  " : "FAIL  ") + n); }
    static final UUID U = new UUID(0, 7);

    static DisplayDefinition def(String id, int x, int y, int z, Facing f, int cols, int rows) {
        return new DisplayDefinition(id, "world-uuid-1", x, y, z, f, cols, rows, 32, 48, U);
    }

    public static void main(String[] a) throws Exception {
        geometry();
        registry();
        parsers();
        tabs();
        providers();
        System.out.println("\n" + pass + " passed, " + fail + " failed (phase2)");
        System.exit(fail == 0 ? 0 : 1);
    }

    static void geometry() {
        var d = def("a", 10, 64, 10, Facing.SOUTH, 3, 2);
        var ps = DisplayGeometry.panels(d);
        check("geometry: 3x2 screen has 6 panels", ps.size() == 6);
        check("geometry: facing south -> columns run east (+x), row 0 is the top",
                ps.stream().anyMatch(p -> p.col() == 2 && p.row() == 0 && p.x() == 12 && p.y() == 65 && p.z() == 10)
                        && ps.stream().anyMatch(p -> p.col() == 0 && p.row() == 1 && p.x() == 10 && p.y() == 64));
        var north = DisplayGeometry.panels(def("n", 0, 0, 0, Facing.NORTH, 2, 1));
        check("geometry: facing north -> columns run west (-x)", north.get(1).x() == -1 && north.get(1).z() == 0);
        var east = DisplayGeometry.panels(def("e", 0, 0, 0, Facing.EAST, 2, 1));
        check("geometry: facing east -> columns run north (-z)", east.get(1).z() == -1 && east.get(1).x() == 0);
        var west = DisplayGeometry.panels(def("w", 0, 0, 0, Facing.WEST, 2, 1));
        check("geometry: facing west -> columns run south (+z)", west.get(1).z() == 1);
        double[] c = DisplayGeometry.center(d);
        check("geometry: centre of 3x2 south screen", Math.abs(c[0] - 11.5) < 1e-9 && Math.abs(c[1] - 65.0) < 1e-9 && Math.abs(c[2] - 10.5) < 1e-9);
        check("geometry: pixel size = panels x 128", d.pixelWidth() == 384 && d.pixelHeight() == 256);
        check("geometry: overlapping screens detected", DisplayGeometry.overlaps(d, def("b", 12, 65, 10, Facing.SOUTH, 2, 2)));
        check("geometry: adjacent screens do not overlap", !DisplayGeometry.overlaps(d, def("b", 13, 64, 10, Facing.SOUTH, 1, 1)));
        check("geometry: same coordinates in another world do not overlap",
                !DisplayGeometry.overlaps(d, new DisplayDefinition("c", "other", 10, 64, 10, Facing.SOUTH, 3, 2, 32, 48, U)));
        check("geometry: distance to centre", Math.abs(DisplayGeometry.distanceToCenter(d, 11.5, 65, 20.5) - 10.0) < 1e-9);
        for (String bad : new String[]{"", "Has Space", "UPPER", "-x", "a".repeat(33), "../x"}) {
            boolean threw; try { def(bad, 0, 0, 0, Facing.NORTH, 1, 1); threw = false; } catch (IllegalArgumentException e) { threw = true; }
            check("definition: rejects id '" + bad + "'", threw);
        }
        boolean z; try { def("x", 0, 0, 0, Facing.NORTH, 0, 1); z = false; } catch (IllegalArgumentException e) { z = true; }
        check("definition: rejects zero-size screen", z);
    }

    static void registry() throws Exception {
        Path dir = Files.createTempDirectory("desecho-reg");
        Path file = dir.resolve("data").resolve("displays.txt");
        var reg = new DisplayRegistry(new FileDisplayStore(file));
        check("registry: starts empty when no file exists", reg.list().isEmpty());
        check("registry: add works", reg.add(def("lobby", 0, 64, 0, Facing.SOUTH, 4, 2)).ok());
        check("registry: duplicate id refused", !reg.add(def("lobby", 50, 64, 0, Facing.SOUTH, 1, 1)).ok());
        check("registry: overlap refused", !reg.add(def("clash", 1, 64, 0, Facing.SOUTH, 1, 1)).ok());
        reg.add(new DisplayDefinition("odd", "world with space|pipe", -5, -60, 99, Facing.WEST, 2, 3, 10.5, 20.25, U));
        check("registry: update changes ranges", reg.update(reg.get("lobby").get().withRanges(64, 96)).ok());

        var reg2 = new DisplayRegistry(new FileDisplayStore(file));   // simulated restart
        check("persistence: both screens restored after restart", reg2.list().size() == 2);
        check("persistence: all fields restored exactly", reg2.get("odd").get().equals(reg.get("odd").get()) && reg2.get("lobby").get().audioRange() == 64);
        check("persistence: world names with spaces/pipes survive", reg2.get("odd").get().world().equals("world with space|pipe"));
        check("persistence: deletion persisted", reg2.remove("odd").ok() && new DisplayRegistry(new FileDisplayStore(file)).list().size() == 1);
        check("registry: delete of unknown id fails cleanly", !reg2.remove("nope").ok());

        Files.writeString(file, Files.readString(file) + "garbage line\nbad|w|x|1|1|NORTH|1|1|1|1|" + U + "\nlobby|w|0|0|0|NORTH|1|1|1|1|" + U + "\n");
        var reg3 = new DisplayRegistry(new FileDisplayStore(file));
        check("persistence: corrupt/duplicate lines skipped, good data kept", reg3.list().size() == 1 && reg3.loadWarnings().size() == 3);
        check("persistence: warnings contain no filesystem path", reg3.loadWarnings().stream().noneMatch(w -> w.contains(dir.toString())));

        Path ro = Files.createDirectory(dir.resolve("ro"));
        var roReg = new DisplayRegistry(new FileDisplayStore(ro.resolve("d.txt")));
        Files.setPosixFilePermissions(ro, PosixFilePermissions.fromString("r-xr-xr-x"));
        boolean canWrite = Files.isWritable(ro);   // root ignores permissions
        if (!canWrite) {
            check("registry: failed save is rolled back and reported", !roReg.add(def("x", 0, 0, 0, Facing.NORTH, 1, 1)).ok() && roReg.list().isEmpty());
        } else {
            System.out.println("SKIP  registry: rollback-on-save-failure (sandbox runs as a user that ignores file permissions)");
        }
        Files.setPosixFilePermissions(ro, PosixFilePermissions.fromString("rwxr-xr-x"));
        try (var s = Files.list(dir.resolve("data"))) { check("persistence: no temp files left behind", s.noneMatch(p -> p.getFileName().toString().endsWith(".tmp"))); }
    }

    static boolean threw(Runnable r) { try { r.run(); return false; } catch (IllegalArgumentException e) { return e.getMessage() != null && !e.getMessage().isBlank(); } }

    static void parsers() {
        check("time: '90' = 90 s", ArgParsers.parseTimeMs("90") == 90_000);
        check("time: '1:30' = 90 s", ArgParsers.parseTimeMs("1:30") == 90_000);
        check("time: '1:02:03'", ArgParsers.parseTimeMs("1:02:03") == 3_723_000);
        check("time: '1h2m3s'", ArgParsers.parseTimeMs("1h2m3s") == 3_723_000);
        check("time: '2m'", ArgParsers.parseTimeMs("2m") == 120_000);
        check("time: '45s'", ArgParsers.parseTimeMs("45s") == 45_000);
        check("time: '12.5'", ArgParsers.parseTimeMs("12.5") == 12_500);
        for (String bad : new String[]{"", "abc", "1:99", "-5", ":30", "1::2", "1h2x", "99999999", "1:2:3:4"})
            check("time: rejects '" + bad + "'", threw(() -> ArgParsers.parseTimeMs(bad)));
        check("volume: 0 and 100 ok", ArgParsers.parseVolume("0") == 0 && ArgParsers.parseVolume("100") == 100);
        for (String bad : new String[]{"101", "-1", "loud", "", "5.5"}) check("volume: rejects '" + bad + "'", threw(() -> ArgParsers.parseVolume(bad)));
        check("facing: names and letters", ArgParsers.parseFacing("N") == Facing.NORTH && ArgParsers.parseFacing("west") == Facing.WEST);
        check("facing: rejects junk", threw(() -> ArgParsers.parseFacing("up")));
        check("screen id: lowercased and validated", ArgParsers.parseScreenId("Lobby").equals("lobby") && threw(() -> ArgParsers.parseScreenId("a b")));
        check("format time", ArgParsers.formatTime(90_000).equals("1:30") && ArgParsers.formatTime(3_723_000).equals("1:02:03"));
    }

    static void tabs() {
        var player = new TabCompleter.Context(true, false, false, List.of("lobby", "cinema", "arena"), List.of("arena"), List.of("lobby"), List.of("Bob"));
        var admin = new TabCompleter.Context(true, true, true, List.of("lobby", "cinema"), List.of("cinema"), List.of("lobby", "cinema"), List.of("Bob", "Alice"));
        var nobody = new TabCompleter.Context(false, false, false, List.of("lobby"), List.of(), List.of(), List.of());
        var ps = TabCompleter.complete(player, new String[]{""});
        check("tab: player sees play/control/info but no admin commands", ps.contains("play") && ps.contains("stop") && ps.contains("info") && !ps.contains("create") && !ps.contains("force-stop") && !ps.contains("reload"));
        var as = TabCompleter.complete(admin, new String[]{""});
        check("tab: admin sees everything", as.containsAll(List.of("create", "delete", "force-stop", "transfer", "reload", "diagnostics", "status", "play")));
        check("tab: user without desecho.play sees only info/screens", TabCompleter.complete(nobody, new String[]{""}).equals(List.of("info", "screens")));
        check("tab: prefix filtering is case-insensitive", TabCompleter.complete(player, new String[]{"PA"}).equals(List.of("pause")));
        check("tab: play suggests only free screens", TabCompleter.complete(player, new String[]{"play", ""}).equals(List.of("arena")));
        check("tab: stop suggests only screens the player controls", TabCompleter.complete(player, new String[]{"stop", ""}).equals(List.of("lobby")));
        check("tab: admin controls suggest every screen", TabCompleter.complete(admin, new String[]{"pause", ""}).size() == 2);
        check("tab: delete is hidden from ordinary players", TabCompleter.complete(player, new String[]{"delete", ""}).isEmpty());
        check("tab: volume suggests levels", TabCompleter.complete(player, new String[]{"volume", "lobby", "5"}).equals(List.of("50")));
        check("tab: create facing suggestions", TabCompleter.complete(admin, new String[]{"create", "x", "4", "2", "s"}).equals(List.of("south")));
        check("tab: transfer suggests players (admin only)", TabCompleter.complete(admin, new String[]{"transfer", "lobby", "A"}).equals(List.of("Alice"))
                && TabCompleter.complete(player, new String[]{"transfer", "lobby", ""}).isEmpty());
    }

    // ---- providers ----

    static Path script(Path dir, String name, String body) throws Exception {
        Path p = dir.resolve(name);
        Files.writeString(p, "#!/bin/bash\n" + body + "\n");
        Files.setPosixFilePermissions(p, PosixFilePermissions.fromString("rwxr-xr-x"));
        return p;
    }

    static UrlGuard guard() {
        UrlGuard.Resolver r = h -> {
            if (h.matches("[0-9a-fA-F.:]+")) return InetAddress.getAllByName(h);
            if (h.equals("internal.test")) return new InetAddress[]{InetAddress.getByName("10.1.1.1")};
            if (h.endsWith(".test") || h.endsWith(".com") || h.equals("youtu.be")) return new InetAddress[]{InetAddress.getByName("93.184.216.34")};
            throw new UnknownHostException(h);
        };
        return new UrlGuard(Set.of(80, 443), r);
    }

    static ResolveException failure(MediaProvider p, String url) {
        try { p.resolve(URI.create(url)); return null; } catch (ResolveException e) { return e; }
    }

    static void providers() throws Exception {
        Path dir = Files.createTempDirectory("desecho-prov");
        var g = guard();
        Path ok = script(dir, "ok", "echo '{\"title\":\"Hello \\\"World\\\" /etc/passwd\",\"duration\":125.5,\"is_live\":false,\"url\":\"https://cdn.example.test/v.mp4\"}'");
        Path sep = script(dir, "sep", "echo '{\"title\":\"T\",\"duration\":60,\"requested_formats\":[{\"url\":\"https://v.example.test/v\",\"vcodec\":\"avc1\",\"acodec\":\"none\"},{\"url\":\"https://a.example.test/a\",\"vcodec\":\"none\",\"acodec\":\"mp4a\"}]}'");
        Path live = script(dir, "live", "echo '{\"title\":\"Live\",\"is_live\":true,\"duration\":null,\"url\":\"https://cdn.example.test/live.m3u8\"}'");
        Path priv = script(dir, "priv", "echo 'ERROR: [youtube] abc: Private video. Sign in if you have been granted access' >&2; exit 1");
        Path bot = script(dir, "bot", "echo \"ERROR: Sign in to confirm you're not a bot\" >&2; exit 1");
        Path unk = script(dir, "unk", "echo 'ERROR: weird failure at /home/mc/secret/path' >&2; exit 1");
        Path hang = script(dir, "hang", "exec sleep 60");
        Path huge = script(dir, "huge", "head -c 3000000 /dev/zero | tr '\\0' 'a'");
        Path ssrf = script(dir, "ssrf", "echo '{\"title\":\"x\",\"url\":\"http://169.254.169.254/latest/meta-data/\"}'");
        Path junk = script(dir, "junk", "echo 'not json'");
        Path argv = script(dir, "argv", "printf '%s\\n' \"$@\" > " + dir + "/argv.txt; echo '{\"title\":\"x\",\"url\":\"https://cdn.example.test/v.mp4\"}'");
        Path nourl = script(dir, "nourl", "echo '{\"title\":\"x\"}'");

        var yt = new YtDlpProvider("youtube", Set.of("youtube.com", "youtu.be"), ok.toString(), g, 5000, 720);
        var m = yt.resolve(URI.create("https://www.youtube.com/watch?v=abc"));
        check("ytdlp: combined stream -> same URL for video and audio", m.videoUrl().equals(m.audioUrl()) && m.videoUrl().getHost().equals("cdn.example.test"));
        check("ytdlp: duration parsed to ms, not live", m.durationMs() == 126_000 || m.durationMs() == 125_500);
        check("ytdlp: title is sanitized (no paths)", !m.title().contains("/etc/passwd"));
        var ms = new YtDlpProvider("youtube", Set.of("youtube.com"), sep.toString(), g, 5000, 720).resolve(URI.create("https://youtube.com/watch?v=1"));
        check("ytdlp: separate video/audio formats picked correctly", ms.videoUrl().getHost().equals("v.example.test") && ms.audioUrl().getHost().equals("a.example.test"));
        var ml = new YtDlpProvider("twitch", Set.of("twitch.tv"), live.toString(), g, 5000, 720).resolve(URI.create("https://www.twitch.tv/x"));
        check("ytdlp: live stream flagged, duration unknown", ml.live() && ml.durationMs() == -1);

        check("errors: private video explained", failure(new YtDlpProvider("y", Set.of(), priv.toString(), g, 5000, 720), "https://x.test/v").getMessage().contains("private"));
        check("errors: bot check explained", failure(new YtDlpProvider("y", Set.of(), bot.toString(), g, 5000, 720), "https://x.test/v").getMessage().contains("bot verification"));
        var e1 = failure(new YtDlpProvider("y", Set.of(), unk.toString(), g, 5000, 720), "https://x.test/v");
        check("errors: unknown failure is generic and leaks no path", e1 != null && !e1.getMessage().contains("/home") && e1.stage() == FailureStage.EXTRACTION);
        var e2 = failure(new YtDlpProvider("y", Set.of(), dir.resolve("missing").toString(), g, 5000, 720), "https://x.test/v");
        check("errors: missing yt-dlp binary reported plainly", e2 != null && e2.getMessage().contains("not installed") && !e2.getMessage().contains(dir.toString()));
        long t0 = System.currentTimeMillis();
        var e3 = failure(new YtDlpProvider("y", Set.of(), hang.toString(), g, 1000, 720), "https://x.test/v");
        long took = System.currentTimeMillis() - t0;
        check("limits: hung extractor is cut off at the timeout (" + took + " ms)", e3 != null && e3.getMessage().contains("too long") && took < 4000);
        Thread.sleep(300);
        long leftovers = ProcessHandle.current().descendants().filter(h -> h.info().command().orElse("").endsWith("sleep")).count();
        check("limits: timed-out extractor process is killed", leftovers == 0);
        var e4 = failure(new YtDlpProvider("y", Set.of(), huge.toString(), g, 5000, 720), "https://x.test/v");
        check("limits: oversized extractor output rejected", e4 != null && e4.getMessage().contains("too much data"));
        var e5 = failure(new YtDlpProvider("y", Set.of(), ssrf.toString(), g, 5000, 720), "https://x.test/v");
        check("security: extractor-returned internal URL is blocked", e5 != null && e5.stage() == FailureStage.SECURITY);
        check("extractor: non-JSON output handled", failure(new YtDlpProvider("y", Set.of(), junk.toString(), g, 5000, 720), "https://x.test/v") != null);
        check("extractor: JSON with no stream handled", failure(new YtDlpProvider("y", Set.of(), nourl.toString(), g, 5000, 720), "https://x.test/v") != null);

        String nasty = "https://x.test/v?a=1;touch%20" + dir + "/pwned&b=$(id)";
        new YtDlpProvider("y", Set.of(), argv.toString(), g, 5000, 720).resolve(URI.create(nasty));
        List<String> args = Files.readAllLines(dir.resolve("argv.txt"));
        check("security: URL is exactly one argv element, after '--', no shell involved", args.get(args.size() - 1).equals(nasty) && args.get(args.size() - 2).equals("--") && !Files.exists(dir.resolve("pwned")));
        check("security: safe yt-dlp flags always present", args.containsAll(List.of("--ignore-config", "--no-playlist", "--dump-single-json")));

        check("host match: subdomain and exact match", yt.supports(URI.create("https://m.youtube.com/x")) && yt.supports(URI.create("https://youtu.be/x")));
        check("host match: lookalike domains do not match", !yt.supports(URI.create("https://notyoutube.com/x")) && !yt.supports(URI.create("https://youtube.com.evil.test/x")));

        var direct = new DirectMediaProvider(g, DirectMediaProvider.DEFAULT_EXTENSIONS);
        check("direct: recognises mp4/webm/m3u8/mpd by path", direct.supports(URI.create("https://a.test/x.MP4?t=1")) && direct.supports(URI.create("https://a.test/p/y.m3u8")) && !direct.supports(URI.create("https://a.test/watch?v=1")));
        var chain = new SourceResolver(g, List.of(direct, new YtDlpProvider("youtube", Set.of("youtube.com"), ok.toString(), g, 5000, 720),
                new YtDlpProvider("generic", Set.of(), ok.toString(), g, 5000, 720)));
        check("resolver: .mp4 URL -> direct provider", chain.resolve("https://media.example.test/clip.mp4").provider().equals("direct"));
        check("resolver: YouTube URL -> youtube provider", chain.resolve("https://www.youtube.com/watch?v=abc").provider().equals("youtube"));
        check("resolver: unknown site -> generic fallback", chain.resolve("https://some.test/page").provider().equals("generic"));
        for (String bad : new String[]{"http://127.0.0.1/a.mp4", "http://internal.test/a.mp4", "file:///etc/passwd", "ftp://x.test/a.mp4", ""}) {
            ResolveException ex = null; try { chain.resolve(bad); } catch (ResolveException e) { ex = e; }
            check("resolver: refuses '" + bad + "' with SECURITY", ex != null && ex.stage() == FailureStage.SECURITY);
        }
        try { MiniJson.parse("{\"a\":[1,2,{\"b\":\"\\u0041\\n\"}],\"c\":null,\"d\":true}"); check("json: parses nested values and escapes", true); }
        catch (Exception e) { check("json: parses nested values and escapes", false); }
        for (String bad : new String[]{"{", "[1,]", "{\"a\":}", "\"x", "{} x", "[".repeat(200)}) {
            boolean t; try { MiniJson.parse(bad); t = false; } catch (MiniJson.JsonException e) { t = true; }
            check("json: rejects malformed '" + (bad.length() > 10 ? bad.substring(0, 10) + "..." : bad) + "'", t);
        }
    }
}
