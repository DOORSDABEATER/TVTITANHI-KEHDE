package dev.des.desecho.core;

import dev.des.desecho.core.display.PaletteQuantizer;
import dev.des.desecho.core.display.PanelDiff;
import dev.des.desecho.core.media.*;
import dev.des.desecho.core.permission.*;
import dev.des.desecho.core.playback.*;
import dev.des.desecho.core.security.*;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Dependency-free test runner (no network, no JUnit). Exit code 1 if anything fails. */
public final class TestMain {
    static int pass, fail;

    static void check(String name, boolean ok) {
        if (ok) pass++; else fail++;
        System.out.println((ok ? "PASS  " : "FAIL  ") + name);
    }

    static final UUID ALICE = UUID.fromString("00000000-0000-0000-0000-00000000a11c");
    static final UUID BOB = UUID.fromString("00000000-0000-0000-0000-0000000000b0");
    static final UUID OP = UUID.fromString("00000000-0000-0000-0000-000000000099");
    static Actor alice() { return new Actor(ALICE, "Alice", true, false, false); }
    static Actor bob() { return new Actor(BOB, "Bob", true, false, false); }
    static Actor op() { return new Actor(OP, "Op", true, true, true); }

    static SessionManager mgr(List<String> log) { return new SessionManager(new SessionManager.Limits(8), log::add); }

    public static void main(String[] args) throws Exception {
        permissions();
        clock();
        urlGuard();
        localMedia();
        display();
        sanitizer();
        pacer();
        ffmpegIntegration();
        System.out.println("\n" + pass + " passed, " + fail + " failed");
        System.exit(fail == 0 ? 0 : 1);
    }

    static void permissions() throws Exception {
        List<String> log = new ArrayList<>();
        var m = mgr(log);
        var r = m.play(alice(), "lobby", "https://example.test/a.mp4");
        check("player with play permission starts a session and owns it", r.ok() && r.session().ownerId().equals(ALICE));
        m.markReady(r.session(), 0);
        check("owner can pause", m.pause(alice(), "lobby").ok());
        check("owner can resume", m.resume(alice(), "lobby").ok());
        check("owner can seek", m.seek(alice(), "lobby", 5000).ok());
        check("owner can set volume", m.setVolume(alice(), "lobby", 40).ok() && r.session().volume() == 40);
        check("owner can mute", m.toggleMute(alice(), "lobby").ok() && r.session().muted());

        check("non-owner cannot pause", !m.pause(bob(), "lobby").ok());
        check("non-owner cannot resume", !m.resume(bob(), "lobby").ok());
        check("non-owner cannot seek", !m.seek(bob(), "lobby", 1).ok());
        check("non-owner cannot change volume", !m.setVolume(bob(), "lobby", 1).ok());
        check("non-owner cannot mute", !m.toggleMute(bob(), "lobby").ok());
        check("non-owner cannot stop", !m.stop(bob(), "lobby").ok() && m.get("lobby").isPresent());
        check("non-owner cannot force-stop", !m.forceStop(bob(), "lobby").ok() && m.get("lobby").isPresent());
        check("non-owner cannot transfer", !m.transfer(bob(), "lobby", BOB, "Bob").ok() && r.session().ownerId().equals(ALICE));
        check("denied attempts are audit-logged", log.stream().anyMatch(s -> s.startsWith("DENIED")));

        for (Action a : new Action[]{Action.CREATE_DISPLAY, Action.DELETE_DISPLAY, Action.CONFIGURE_DISPLAY, Action.FORCE_STOP, Action.TRANSFER}) {
            check("ordinary player denied " + a, !AccessPolicy.check(alice(), a, ALICE).allowed());
        }
        check("display-manage permission allows display actions only",
                AccessPolicy.check(new Actor(BOB, "Bob", true, true, false), Action.DELETE_DISPLAY, null).allowed()
                        && !AccessPolicy.check(new Actor(BOB, "Bob", true, true, false), Action.FORCE_STOP, ALICE).allowed());
        check("player without desecho.play cannot start", !m.play(new Actor(BOB, "Bob", false, false, false), "other", "x").ok());

        check("op can pause someone else's session", m.pause(op(), "lobby").ok());
        check("op can seek someone else's session", m.seek(op(), "lobby", 100).ok());
        check("op overrides are audit-logged", log.stream().anyMatch(s -> s.startsWith("ADMIN_OVERRIDE")));
        check("op transfer works and is logged", m.transfer(op(), "lobby", BOB, "Bob").ok() && log.stream().anyMatch(s -> s.startsWith("TRANSFER")));
        check("after transfer old owner loses control", !m.resume(alice(), "lobby").ok());
        check("after transfer new owner gains control", m.resume(bob(), "lobby").ok());
        Actor renamed = new Actor(BOB, "TotallyNewName", true, false, false);
        check("ownership follows UUID, not name (rename keeps control)", m.setVolume(renamed, "lobby", 10).ok());
        check("op can force-stop any session", m.forceStop(op(), "lobby").ok() && m.get("lobby").isEmpty());

        var m2 = mgr(new ArrayList<>());
        m2.play(alice(), "a", "x");
        check("occupied screen refuses a second playback", !m2.play(bob(), "a", "y").ok());
        check("a different screen is independent", m2.play(bob(), "b", "y").ok());
        check("stopping one screen leaves the other running", m2.stop(alice(), "a").ok() && m2.get("b").isPresent());
        var failing = m2.get("b").get();
        m2.fail(failing, FailureStage.DECODING, "boom");
        check("failed session can be replaced on that screen", m2.play(alice(), "b", "z").ok());

        var m3 = new SessionManager(new SessionManager.Limits(2), x -> { });
        m3.play(alice(), "1", "x"); m3.play(alice(), "2", "x");
        check("max active sessions limit enforced", !m3.play(alice(), "3", "x").ok());
        check("stopAll returns and clears every session", m3.stopAll("test").size() == 2 && m3.all().isEmpty());

        var m4 = mgr(new ArrayList<>());
        int threads = 32;
        var wins = new AtomicInteger();
        var start = new CountDownLatch(1);
        var pool = Executors.newFixedThreadPool(threads);
        for (int i = 0; i < threads; i++) {
            final UUID id = new UUID(0, 1000 + i);
            pool.submit(() -> {
                try { start.await(); } catch (InterruptedException e) { return; }
                if (m4.play(new Actor(id, "p", true, false, false), "contested", "x").ok()) wins.incrementAndGet();
            });
        }
        start.countDown(); pool.shutdown(); pool.awaitTermination(10, TimeUnit.SECONDS);
        check("32 racing players: exactly one wins the screen", wins.get() == 1);
    }

    static void clock() {
        AtomicLong now = new AtomicLong();
        var c = new PlaybackClock(now::get);
        c.start(0);
        now.addAndGet(2_000_000_000L);
        check("clock advances while running", c.positionMs() == 2000);
        c.pause(); now.addAndGet(5_000_000_000L);
        check("clock frozen while paused", c.positionMs() == 2000);
        c.resume(); now.addAndGet(1_000_000_000L);
        check("clock continues after resume", c.positionMs() == 3000);
        c.seek(10_000); now.addAndGet(500_000_000L);
        check("seek moves position and keeps running", c.positionMs() == 10_500);
        c.pause(); c.seek(20_000);
        check("seek while paused stays paused at new position", c.positionMs() == 20_000 && !c.isRunning());
    }

    static UrlGuard guard() {
        UrlGuard.Resolver r = h -> switch (h) {
            case "example.test" -> new InetAddress[]{InetAddress.getByName("93.184.216.34")};
            case "internal.test" -> new InetAddress[]{InetAddress.getByName("10.0.0.5")};
            case "rebind.test" -> new InetAddress[]{InetAddress.getByName("93.184.216.34"), InetAddress.getByName("127.0.0.1")};
            default -> {
                if (!h.matches("[0-9a-fA-F.:]+")) throw new UnknownHostException(h);
                yield InetAddress.getAllByName(h);
            }
        };
        return new UrlGuard(Set.of(80, 443), r);
    }

    static void urlGuard() {
        var g = guard();
        String[] ok = {"https://example.test/v.mp4", "http://8.8.8.8/x", "HTTPS://example.test:443/a?b=c"};
        for (String u : ok) { boolean good; try { g.validate(u); good = true; } catch (SecurityRejection e) { good = false; } check("allows " + u, good); }
        String[] bad = {
            "http://127.0.0.1/", "http://[::1]/", "http://169.254.169.254/latest/meta-data/", "http://10.0.0.5/",
            "http://192.168.1.1/", "http://172.16.0.1/", "http://172.31.255.255/", "http://0.0.0.0/", "http://100.64.0.1/",
            "http://2130706433/", "http://0x7f.0.0.1/", "http://[::ffff:127.0.0.1]/", "http://[fd00::1]/", "http://[fe80::1]/",
            "http://[64:ff9b::7f00:1]/", "http://[2002:7f00:1::1]/", "http://internal.test/", "http://rebind.test/",
            "http://localhost/", "file:///etc/passwd", "ftp://example.test/x", "gopher://example.test/", "javascript:alert(1)",
            "http://user:pw@example.test/", "http://example.test:22/", "http://example.test:25565/",
            "http://example.test/a b", "", "   ", "not a url", "http:///nohost"};
        for (String u : bad) { boolean rejected; try { g.validate(u); rejected = false; } catch (SecurityRejection e) { rejected = true; } check("rejects '" + u + "'", rejected); }
        boolean tooLong; try { g.validate("https://example.test/" + "a".repeat(3000)); tooLong = false; } catch (SecurityRejection e) { tooLong = true; }
        check("rejects over-long URL", tooLong);
    }

    static void localMedia() throws Exception {
        Path base = Files.createTempDirectory("desecho-lm");
        Path root = Files.createDirectory(base.resolve("media"));
        Files.createDirectories(root.resolve("sub"));
        Files.writeString(root.resolve("ok.mp4"), "x");
        Files.writeString(root.resolve("sub/deep.webm"), "x");
        Files.writeString(root.resolve("notes.txt"), "x");
        Files.writeString(base.resolve("secret.mp4"), "x");
        Files.createSymbolicLink(root.resolve("escape.mp4"), base.resolve("secret.mp4"));
        var p = new LocalMediaPolicy(List.of(root), Set.of("mp4", "webm", "mkv"));
        check("local: plain file resolves inside root", ok(p, "ok.mp4"));
        check("local: nested file resolves", ok(p, "sub/deep.webm"));
        check("local: '../secret.mp4' rejected", !ok(p, "../secret.mp4"));
        check("local: 'sub/../../secret.mp4' rejected", !ok(p, "sub/../../secret.mp4"));
        check("local: absolute path rejected", !ok(p, base.resolve("secret.mp4").toString()));
        check("local: /etc/passwd rejected", !ok(p, "/etc/passwd"));
        check("local: symlink escaping the root rejected", !ok(p, "escape.mp4"));
        check("local: disallowed extension rejected", !ok(p, "notes.txt"));
        check("local: missing file rejected", !ok(p, "nope.mp4"));
        check("local: NUL byte rejected", !ok(p, "ok.mp4\0.txt"));
        String m1 = msg(p, "nope.mp4"), m2 = msg(p, "../secret.mp4");
        check("local: all failures share one generic message (no probing)", m1.equals(m2) && !m1.contains(base.toString()));
    }

    static boolean ok(LocalMediaPolicy p, String s) { try { p.resolve(s); return true; } catch (SecurityRejection e) { return false; } }
    static String msg(LocalMediaPolicy p, String s) { try { p.resolve(s); return ""; } catch (SecurityRejection e) { return e.getMessage(); } }

    static void display() {
        var plan = QualityPreset.ECONOMY.plan(1024, 512, 30);
        check("preset: economy on 8x4 maps decodes at half size, upscale 2, fps 15", plan.decodeW() == 512 && plan.decodeH() == 256 && plan.upscale() == 2 && plan.fps() == 15);
        check("preset: balanced on 640x384 needs no upscale", QualityPreset.BALANCED.plan(640, 384, 30).upscale() == 1);
        check("preset: admin max fps caps preset fps", QualityPreset.ULTRA.plan(512, 512, 12).fps() == 12);

        int[] pal = new int[256];
        pal[4] = 0xFF000000; pal[5] = 0xFFFFFFFF; pal[6] = 0xFFFF0000; pal[7] = 0xFF00FF00; pal[8] = 0xFF0000FF;
        var q = new PaletteQuantizer(pal, 4);
        check("quantizer: pure red -> red index", q.indexOf(255, 0, 0) == 6);
        check("quantizer: near-white -> white index", q.indexOf(250, 250, 250) == 5);
        boolean never = true;
        for (int i = 0; i < 4096; i++) { int idx = q.indexOf((i * 37) & 255, (i * 91) & 255, (i * 13) & 255) & 0xff; if (idx < 4) never = false; }
        check("quantizer: never emits transparent indices (<4)", never);
        byte[] rgb = {(byte) 255, 0, 0, 0, (byte) 255, 0};
        byte[] dst = new byte[4 * 2];
        q.blit(rgb, 2, 1, 2, dst, 4, 2);
        check("quantizer: integer upscale blit", dst[0] == 6 && dst[1] == 6 && dst[2] == 7 && dst[3] == 7 && dst[4] == 6 && dst[7] == 7);

        int cols = 2, rows = 1, w = 256, h = 128;
        byte[] a = new byte[w * h], b = a.clone();
        check("diff: identical frames -> no updates", PanelDiff.diff(a, b, cols, rows).isEmpty());
        b[10 * w + 20] = 9;
        var u = PanelDiff.diff(a, b, cols, rows);
        check("diff: one changed pixel -> one 1x1 update at the right spot",
                u.size() == 1 && u.get(0).col() == 0 && u.get(0).rect().equals(new PanelDiff.Rect(20, 10, 1, 1)) && u.get(0).data()[0] == 9);
        b[5 * w + 127] = 3; b[6 * w + 128] = 4;
        var u2 = PanelDiff.diff(a, b, cols, rows);
        check("diff: change on both sides of a panel border -> two updates, border-relative coords",
                u2.size() == 2 && u2.get(1).col() == 1 && u2.get(1).rect().equals(new PanelDiff.Rect(0, 6, 1, 1)));
        check("diff: null previous frame -> full update of every panel", PanelDiff.diff(null, b, cols, rows).size() == 2
                && PanelDiff.diff(null, b, cols, rows).get(0).data().length == 128 * 128);

        // Benchmark on THIS container only; not a statement about the target server.
        var big = new byte[1024 * 512 * 3];
        new Random(1).nextBytes(big);
        byte[] out = new byte[1024 * 512];
        for (int i = 0; i < 20; i++) q.blit(big, 1024, 512, 1, out, 1024, 512);
        long t0 = System.nanoTime();
        for (int i = 0; i < 50; i++) q.blit(big, 1024, 512, 1, out, 1024, 512);
        System.out.printf("INFO  quantize 1024x512 frame: %.2f ms (this sandbox, not your server)%n", (System.nanoTime() - t0) / 50 / 1e6);
    }

    static void sanitizer() {
        String s = ErrorSanitizer.sanitize("Error opening input: /home/mc/media/secret.mp4: No such file; https://x.test/a.mp4?token=abc C:\\Users\\me\\v.mp4");
        check("sanitizer removes paths, URLs/query tokens, windows paths", !s.contains("/home") && !s.contains("token") && !s.contains("Users") && s.contains("<path>") && s.contains("<url>"));
        check("sanitizer truncates", ErrorSanitizer.sanitize("a".repeat(1000)).length() <= 203);
    }

    static void pacer() throws Exception {
        var q = new FrameQueue(8);
        for (int i = 0; i < 5; i++) q.put(new Frame(i, i * 100L, new byte[0]), false);
        var p0 = FramePacer.pick(q, -1);
        check("pacer: nothing due yet -> null", p0.frame() == null);
        var p1 = FramePacer.pick(q, 250);
        check("pacer: late consumer gets newest due frame and skips stale ones", p1.frame().index() == 2 && p1.skipped() == 2 && q.size() == 2);
        var q2 = new FrameQueue(2);
        for (int i = 0; i < 5; i++) q2.put(new Frame(i, i, new byte[0]), true);
        check("queue: drop-oldest stays bounded and keeps newest", q2.size() == 2 && q2.peek().index() == 3 && q2.dropped() == 3);
    }

    static void ffmpegIntegration() throws Exception {
        Path dir = Files.createTempDirectory("desecho-ff");
        Path root = Files.createDirectory(dir.resolve("media"));
        Path clip = root.resolve("test.mp4");
        runOrDie(List.of("ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=duration=30:size=640x360:rate=25",
                "-f", "lavfi", "-i", "sine=frequency=440:duration=30", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-shortest", clip.toString()));
        var policy = new LocalMediaPolicy(List.of(root), Set.of("mp4"));
        var src = new FfmpegCommands.Source(policy.resolve("test.mp4").toString(), true);
        int W = 256, H = 256, FPS = 10;
        var plan = new QualityPreset.CanvasPlan(W, H, 1, FPS);

        // 1) bounded decode of exactly 3 seconds, aspect preserved
        var q = new FrameQueue(64);
        var latch = new CountDownLatch(1);
        var endRef = new AtomicReference<FfmpegVideoDecoder.End>();
        try (var d = FfmpegVideoDecoder.start("t1", FfmpegCommands.video("ffmpeg", src, 0, plan, 3), W, H, FPS, 0, q, false,
                (e, m) -> { endRef.set(e); latch.countDown(); })) {
            check("ffmpeg: decoder ends on its own", latch.await(20, TimeUnit.SECONDS) && endRef.get() == FfmpegVideoDecoder.End.EOF);
            int n = q.size();
            check("ffmpeg: ~30 frames for 3 s at 10 fps (got " + n + ")", n >= 29 && n <= 31);
            Frame f = null; for (int i = 0; i < 15; i++) f = q.poll();
            boolean barsBlack = rowBlack(f.rgb(), W, 5) && rowBlack(f.rgb(), W, 250);
            boolean middleLit = !rowBlack(f.rgb(), W, 128);
            check("ffmpeg: 16:9 source in square canvas is letterboxed, not stretched", barsBlack && middleLit);
            check("ffmpeg: frame timestamps follow fps", f.ptsMs() == 1400);
        }

        // 2) seek: decoding from 2 s stamps frames from 2000 ms
        var q2 = new FrameQueue(64);
        var l2 = new CountDownLatch(1);
        try (var d = FfmpegVideoDecoder.start("t2", FfmpegCommands.video("ffmpeg", src, 2000, plan, 1), W, H, FPS, 2000, q2, false, (e, m) -> l2.countDown())) {
            l2.await(20, TimeUnit.SECONDS);
            check("ffmpeg: seeked decode starts at 2000 ms with ~10 frames", q2.peek() != null && q2.peek().ptsMs() == 2000 && q2.size() >= 9 && q2.size() <= 11);
        }

        // 3) backpressure + cleanup: tiny queue, long clip; ffmpeg must stall instead of racing ahead, and die on close()
        var q3 = new FrameQueue(4);
        var closedEnd = new AtomicReference<FfmpegVideoDecoder.End>();
        var d3 = FfmpegVideoDecoder.start("t3", FfmpegCommands.video("ffmpeg", src, 0, plan, 30), W, H, FPS, 0, q3, false, (e, m) -> closedEnd.set(e));
        Thread.sleep(1500);
        check("ffmpeg: bounded queue stays within capacity while consumer is idle", q3.size() <= 4 && d3.isAlive());
        d3.close();
        Thread.sleep(200);
        check("ffmpeg: close() kills the process", !d3.isAlive());
        check("ffmpeg: listener told CLOSED", closedEnd.get() == FfmpegVideoDecoder.End.CLOSED);
        boolean leaked = Thread.getAllStackTraces().keySet().stream().anyMatch(t -> t.isAlive() && t.getName().startsWith("desecho-") && t.getName().contains("t3"));
        check("ffmpeg: no decoder threads left behind after close()", !leaked);

        // 4) bad input -> ERROR with sanitized message
        var l4 = new CountDownLatch(1);
        var msg = new AtomicReference<String>();
        var endR = new AtomicReference<FfmpegVideoDecoder.End>();
        Path bad = root.resolve("bad.mp4");
        Files.writeString(bad, "this is not a video");
        var badSrc = new FfmpegCommands.Source(policy.resolve("bad.mp4").toString(), true);
        try (var d = FfmpegVideoDecoder.start("t4", FfmpegCommands.video("ffmpeg", badSrc, 0, plan, 3), W, H, FPS, 0, new FrameQueue(4), false,
                (e, m) -> { endR.set(e); msg.set(m); l4.countDown(); })) {
            l4.await(20, TimeUnit.SECONDS);
            check("ffmpeg: undecodable file -> ERROR (not a crash)", endR.get() == FfmpegVideoDecoder.End.ERROR);
            check("ffmpeg: error text has no filesystem path", msg.get() != null && !msg.get().contains(dir.toString()) && !msg.get().contains("/tmp"));
        }

        // 5) command safety
        var cmd = FfmpegCommands.video("ffmpeg", src, 0, plan, 3);
        check("command: local source whitelists only 'file'", cmd.get(cmd.indexOf("-protocol_whitelist") + 1).equals("file"));
        var rcmd = FfmpegCommands.video("ffmpeg", new FfmpegCommands.Source("https://example.test/v.mp4", false), 0, plan, 3);
        check("command: remote source whitelists only network protocols", rcmd.get(rcmd.indexOf("-protocol_whitelist") + 1).equals("http,https,tcp,tls,crypto"));
        check("command: target is a single argument right after -i", rcmd.get(rcmd.indexOf("-i") + 1).equals("https://example.test/v.mp4"));
        check("command: whitelist comes before -i", rcmd.indexOf("-protocol_whitelist") < rcmd.indexOf("-i"));
        check("command: refuses non-http remote", throwsIAE(() -> new FfmpegCommands.Source("concat:/etc/passwd", false)));
        check("command: refuses relative local path", throwsIAE(() -> new FfmpegCommands.Source("../x.mp4", true)));

        // 6) audio extraction shape: 48 kHz mono s16le => 96000 bytes/s
        var acmd = FfmpegCommands.audio("ffmpeg", src, 0, 2);
        Process ap = new ProcessBuilder(acmd).redirectError(ProcessBuilder.Redirect.DISCARD).start();
        byte[] pcm = ap.getInputStream().readAllBytes();
        ap.waitFor();
        check("audio: 2 s of PCM is ~192000 bytes (got " + pcm.length + ")", Math.abs(pcm.length - 192000) < 4000);
    }

    interface Thrower { void run() throws Exception; }
    static boolean throwsIAE(Thrower t) { try { t.run(); return false; } catch (IllegalArgumentException e) { return true; } catch (Exception e) { return false; } }

    static boolean rowBlack(byte[] rgb, int w, int y) {
        for (int x = 0; x < w; x++) { int i = (y * w + x) * 3; if ((rgb[i] & 0xff) > 8 || (rgb[i + 1] & 0xff) > 8 || (rgb[i + 2] & 0xff) > 8) return false; }
        return true;
    }

    static void runOrDie(List<String> cmd) throws Exception {
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        String out = new String(p.getInputStream().readAllBytes());
        if (p.waitFor() != 0) throw new IllegalStateException("setup failed: " + out);
    }

    static final class AtomicReference<T> { private volatile T v; void set(T t) { v = t; } T get() { return v; } }
}
