plugins { java }

val paperApi: String by project
val apiVersion: String by project
val javaVersion: String by project

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:$paperApi")
}

java { toolchain.languageVersion.set(JavaLanguageVersion.of(javaVersion.toInt())) }

// The pure-Java core is compiled straight into the plugin jar (no shading step, no extra dependency).
sourceSets { main { java.srcDir("../core/src/main/java") } }

tasks.processResources {
    filesMatching("plugin.yml") { expand("version" to project.version, "apiVersion" to apiVersion) }
}

tasks.jar { archiveFileName.set("DESECHO.jar") }
