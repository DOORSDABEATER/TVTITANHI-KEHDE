package dev.des.desecho.plugin;

import dev.des.desecho.core.command.ArgParsers;
import dev.des.desecho.core.command.TabCompleter;
import dev.des.desecho.core.display.DisplayDefinition;
import dev.des.desecho.core.display.DisplayGeometry;
import dev.des.desecho.core.display.DisplayRegistry;
import dev.des.desecho.core.media.FfmpegCommands;
import dev.des.desecho.core.permission.AccessPolicy;
import dev.des.desecho.core.permission.Action;
import dev.des.desecho.core.permission.Actor;
import dev.des.desecho.core.playback.FailureStage;
import dev.des.desecho.core.playback.PlaybackSession;
import dev.des.desecho.core.playback.SessionManager;
import dev.des.desecho.core.playback.SessionState;
import dev.des.desecho.core.provider.ResolveException;
import dev.des.desecho.core.provider.ResolvedMedia;
import dev.des.desecho.core.security.SecurityRejection;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.logging.Level;

final class DesechoCommand implements CommandExecutor, org.bukkit.command.TabCompleter {
    private static final String PREFIX = "[DESECHO] ";
    private final DesechoPlugin plugin;
    private final DisplayRegistry registry;
    private final SessionManager sessions;
    private final ScreenManager screens;
    private final ExecutorService workers;
    private final Map<UUID, Long> lastSubmit = new ConcurrentHashMap<>();

    DesechoCommand(DesechoPlugin plugin, DisplayRegistry registry, SessionManager sessions, ScreenManager screens, ExecutorService workers) {
        this.plugin = plugin; this.registry = registry; this.sessions = sessions; this.screens = screens; this.workers = workers;
    }

    private static void send(CommandSender s, String m) { s.sendMessage(PREFIX + m); }

    private void sync(Runnable r) { Bukkit.getScheduler().runTask(plugin, r); }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] a) {
        if (a.length == 0) { send(sender, "Usage: /desecho <screens|info|play|stop|pause|resume|seek|volume|mute" + (ActorFactory.of(sender).admin() ? "|create|delete|configure|force-stop|transfer|reload|diagnostics|status" : "") + ">"); return true; }
        Actor actor = ActorFactory.of(sender);
        try {
            switch (a[0].toLowerCase(Locale.ROOT)) {
                case "screens" -> screensList(sender);
                case "info" -> info(sender, a);
                case "play" -> play(sender, actor, a);
                case "stop" -> control(sender, a, id -> sessions.stop(actor, id), true);
                case "force-stop" -> control(sender, a, id -> sessions.forceStop(actor, id), true);
                case "pause" -> control(sender, a, id -> sessions.pause(actor, id), false);
                case "resume" -> control(sender, a, id -> sessions.resume(actor, id), false);
                case "mute" -> control(sender, a, id -> sessions.toggleMute(actor, id), false);
                case "seek" -> { need(a, 3, "/desecho seek <screen> <time>"); long ms = ArgParsers.parseTimeMs(a[2]); control(sender, a, id -> sessions.seek(actor, id, ms), false); }
                case "volume" -> { need(a, 3, "/desecho volume <screen> <0-100>"); int v = ArgParsers.parseVolume(a[2]); control(sender, a, id -> sessions.setVolume(actor, id, v), false); }
                case "create" -> create(sender, actor, a);
                case "delete" -> delete(sender, actor, a);
                case "configure" -> configure(sender, actor, a);
                case "transfer" -> transfer(sender, actor, a);
                case "reload" -> { adminOnly(actor); plugin.reloadSettings(); send(sender, "Configuration reloaded (max-active-sessions needs a restart)."); }
                case "diagnostics" -> { adminOnly(actor); diagnostics(sender); }
                case "status" -> { adminOnly(actor); status(sender); }
                default -> send(sender, "Unknown subcommand. Try /desecho with no arguments.");
            }
        } catch (IllegalArgumentException e) {
            send(sender, e.getMessage());
        } catch (SecurityException e) {
            send(sender, "Administrators only.");
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Command failed", e);
            send(sender, "An internal error occurred; see the server log.");
        }
        return true;
    }

    private static void need(String[] a, int n, String usage) { if (a.length < n) throw new IllegalArgumentException("Usage: " + usage); }
    private static void adminOnly(Actor actor) { if (!AccessPolicy.check(actor, Action.TRANSFER, null).allowed()) throw new SecurityException(); }

    private DisplayDefinition screen(String raw) {
        String id = ArgParsers.parseScreenId(raw);
        return registry.get(id).orElseThrow(() -> new IllegalArgumentException("There is no screen named '" + id + "'. Try /desecho screens."));
    }

    // ---- read-only ----

    private void screensList(CommandSender s) {
        List<DisplayDefinition> l = registry.list();
        if (l.isEmpty()) { send(s, "No screens have been created yet."); return; }
        for (DisplayDefinition d : l) {
            var ses = sessions.get(d.id());
            String state = ses.isPresent() ? ses.get().state().name().toLowerCase(Locale.ROOT) : "free";
            send(s, d.id() + " - " + d.cols() + "x" + d.rows() + " maps, " + state);
        }
    }

    private void info(CommandSender s, String[] a) {
        need(a, 2, "/desecho info <screen>");
        DisplayDefinition d = screen(a[1]);
        send(s, d.id() + ": " + d.cols() + "x" + d.rows() + " maps (" + d.pixelWidth() + "x" + d.pixelHeight() + " px), audio range " + d.audioRange() + ", view distance " + d.viewDistance());
        var ses = sessions.get(d.id());
        if (ses.isEmpty()) { send(s, "Nothing is playing."); return; }
        PlaybackSession p = ses.get();
        OfflinePlayer owner = Bukkit.getOfflinePlayer(p.ownerId());
        String name = p.ownerId().equals(Actor.CONSOLE_ID) ? "console" : (owner.getName() == null ? p.ownerId().toString() : owner.getName());
        send(s, "State: " + p.state().name().toLowerCase(Locale.ROOT) + ", position " + ArgParsers.formatTime(p.clock().positionMs())
                + ", owner " + name + ", volume " + p.volume() + (p.muted() ? " (muted)" : ""));
        if (p.state() == SessionState.FAILED) send(s, "Failed (" + p.failureStage() + "): " + p.failureMessage());
    }

    // ---- playback ----

    private void play(CommandSender sender, Actor actor, String[] a) {
        need(a, 3, "/desecho play <screen> <url | file:name.mp4>");
        DisplayDefinition d = screen(a[1]);
        String target = a[2];
        if (!actor.admin() && plugin.settings().rateLimitMs() > 0) {
            long now = System.currentTimeMillis();
            Long last = lastSubmit.get(actor.id());
            if (last != null && now - last < plugin.settings().rateLimitMs()) throw new IllegalArgumentException("Please wait a few seconds between videos.");
            lastSubmit.put(actor.id(), now);
        }
        var r = sessions.play(actor, d.id(), target);
        if (!r.ok()) { send(sender, r.message()); return; }
        PlaybackSession s = r.session();
        send(sender, "Looking up the video...");
        var resolver = plugin.resolver();
        var local = plugin.localPolicy();
        workers.submit(() -> {
            try {
                FfmpegCommands.Source src;
                String title;
                if (target.regionMatches(true, 0, "file:", 0, 5)) {
                    Path p = local.resolve(target.substring(5));
                    src = new FfmpegCommands.Source(p.toString(), true);
                    title = p.getFileName().toString();
                } else {
                    ResolvedMedia m = resolver.resolve(target);
                    src = new FfmpegCommands.Source(m.videoUrl().toString(), false);
                    title = m.title();
                }
                sync(() -> {
                    if (sessions.get(d.id()).orElse(null) != s) return; // stopped while resolving
                    screens.startPlayback(s, d, src);
                    send(sender, "Loading: " + title + " (audio is not available in this build)");
                });
            } catch (ResolveException e) {
                failed(sender, s, e.stage(), e.getMessage());
            } catch (SecurityRejection e) {
                failed(sender, s, FailureStage.SECURITY, e.getMessage());
            } catch (Throwable t) {
                plugin.getLogger().log(Level.WARNING, "Playback setup failed", t);
                failed(sender, s, FailureStage.EXTRACTION, "Something went wrong starting that video.");
            }
        });
    }

    private void failed(CommandSender sender, PlaybackSession s, FailureStage stage, String msg) {
        sessions.end(s);
        sync(() -> send(sender, "Couldn't play that (" + stage.name().toLowerCase(Locale.ROOT) + "): " + msg));
    }

    private interface Op { SessionManager.Result run(String id); }

    private void control(CommandSender sender, String[] a, Op op, boolean releasesScreen) {
        need(a, 2, "/desecho " + a[0] + " <screen>");
        DisplayDefinition d = screen(a[1]);
        var r = op.run(d.id());
        send(sender, r.message());
        if (r.ok() && releasesScreen) screens.release(d.id());
    }

    private void transfer(CommandSender sender, Actor actor, String[] a) {
        need(a, 3, "/desecho transfer <screen> <player>");
        DisplayDefinition d = screen(a[1]);
        Player online = Bukkit.getPlayerExact(a[2]);
        OfflinePlayer target = online != null ? online : Bukkit.getOfflinePlayerIfCached(a[2]);
        if (target == null) throw new IllegalArgumentException("That player isn't online and isn't known to the server.");
        send(sender, sessions.transfer(actor, d.id(), target.getUniqueId(), a[2]).message());
    }

    // ---- display management ----

    private void create(CommandSender sender, Actor actor, String[] a) {
        if (!AccessPolicy.check(actor, Action.CREATE_DISPLAY, null).allowed()) throw new IllegalArgumentException("You don't have permission to manage displays.");
        if (!(sender instanceof Player p)) throw new IllegalArgumentException("Run this in-game: look at the wall block for the bottom-left corner.");
        need(a, 2, "/desecho create <id> [cols] [rows]   (look at the wall block that is the screen's bottom-left)");
        Settings st = plugin.settings();
        String id = ArgParsers.parseScreenId(a[1]);
        int cols = a.length > 2 ? ArgParsers.parseInt("Columns", a[2], 1, st.maxCols()) : 4;
        int rows = a.length > 3 ? ArgParsers.parseInt("Rows", a[3], 1, st.maxRows()) : 3;
        RayTraceResult hit = p.rayTraceBlocks(8);
        if (hit == null || hit.getHitBlock() == null || hit.getHitBlockFace() == null) throw new IllegalArgumentException("Look at a wall block within 8 blocks.");
        BlockFace face = hit.getHitBlockFace();
        DisplayDefinition.Facing facing = switch (face) {
            case NORTH -> DisplayDefinition.Facing.NORTH; case SOUTH -> DisplayDefinition.Facing.SOUTH;
            case EAST -> DisplayDefinition.Facing.EAST; case WEST -> DisplayDefinition.Facing.WEST;
            default -> throw new IllegalArgumentException("Look at the side of a wall, not its top or bottom.");
        };
        Block anchor = hit.getHitBlock().getRelative(face);
        DisplayDefinition d = new DisplayDefinition(id, anchor.getWorld().getUID().toString(), anchor.getX(), anchor.getY(), anchor.getZ(),
                facing, cols, rows, st.defaultAudioRange(), st.defaultViewDistance(), p.getUniqueId());
        for (DisplayGeometry.Panel pn : DisplayGeometry.panels(d)) {
            Block front = anchor.getWorld().getBlockAt(pn.x(), pn.y(), pn.z());
            Block behind = front.getRelative(face.getOppositeFace());
            if (!front.isEmpty() || !behind.getType().isSolid())
                throw new IllegalArgumentException("The screen needs a solid wall behind every panel and free air in front (blocked at " + pn.x() + "," + pn.y() + "," + pn.z() + ").");
        }
        var r = registry.add(d);
        if (!r.ok()) { send(sender, r.message()); return; }
        try {
            screens.addScreen(d);
        } catch (RuntimeException e) {
            registry.remove(id);
            throw new IllegalArgumentException("Could not create the screen: " + e.getMessage());
        }
        send(sender, "Screen '" + id + "' created (" + cols + "x" + rows + " maps, " + d.pixelWidth() + "x" + d.pixelHeight() + " px).");
    }

    private void delete(CommandSender sender, Actor actor, String[] a) {
        if (!AccessPolicy.check(actor, Action.DELETE_DISPLAY, null).allowed()) throw new IllegalArgumentException("You don't have permission to manage displays.");
        need(a, 2, "/desecho delete <screen>");
        DisplayDefinition d = screen(a[1]);
        sessions.get(d.id()).ifPresent(s -> sessions.forceStop(Actor.console(), d.id()));
        screens.removeScreen(d.id());
        send(sender, registry.remove(d.id()).message());
    }

    private void configure(CommandSender sender, Actor actor, String[] a) {
        if (!AccessPolicy.check(actor, Action.CONFIGURE_DISPLAY, null).allowed()) throw new IllegalArgumentException("You don't have permission to manage displays.");
        need(a, 4, "/desecho configure <screen> <audio-range|view-distance> <blocks>");
        DisplayDefinition d = screen(a[1]);
        double v = ArgParsers.parseRange("Value", a[3], 512);
        DisplayDefinition n = switch (a[2].toLowerCase(Locale.ROOT)) {
            case "audio-range" -> d.withRanges(v, d.viewDistance());
            case "view-distance" -> d.withRanges(d.audioRange(), v);
            default -> throw new IllegalArgumentException("Setting must be audio-range or view-distance.");
        };
        send(sender, registry.update(n).message());
    }

    // ---- admin info ----

    private void status(CommandSender s) {
        send(s, "Screens: " + registry.list().size() + ", sessions: " + sessions.all().size() + ", active pipelines: " + screens.activePlayers()
                + ", preset: " + plugin.settings().preset() + ", max fps: " + plugin.settings().maxFps());
        send(s, "Audio output: NOT IMPLEMENTED in this build (Plasmo Voice integration is not written).");
    }

    private void diagnostics(CommandSender s) {
        long threads = Thread.getAllStackTraces().keySet().stream().filter(t -> t.getName().startsWith("desecho-")).count();
        send(s, "Java " + System.getProperty("java.version") + ", desecho threads: " + threads + ", sessions: " + sessions.all().size());
        for (PlaybackSession p : sessions.all()) {
            send(s, p.screenId() + ": " + p.state() + " @" + ArgParsers.formatTime(p.clock().positionMs())
                    + (p.state() == SessionState.FAILED ? " (" + p.failureStage() + ": " + p.failureMessage() + ")" : ""));
        }
        Settings st = plugin.settings();
        workers.submit(() -> {
            String ff = version(st.ffmpeg(), "-version"), yt = version(st.ytDlp(), "--version");
            sync(() -> { send(s, "ffmpeg: " + ff); send(s, "yt-dlp: " + yt); });
        });
    }

    private static String version(String bin, String flag) {
        try {
            Process p = new ProcessBuilder(bin, flag).redirectErrorStream(true).start();
            p.getOutputStream().close();
            String out = new String(p.getInputStream().readNBytes(400));
            p.destroy();
            return out.lines().findFirst().orElse("available");
        } catch (Exception e) {
            return "NOT FOUND";
        }
    }

    // ---- tab completion ----

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        Actor actor = ActorFactory.of(sender);
        List<String> all = new ArrayList<>(), free = new ArrayList<>(), mine = new ArrayList<>();
        for (DisplayDefinition d : registry.list()) {
            all.add(d.id());
            var s = sessions.get(d.id());
            if (s.isEmpty() || s.get().state() == SessionState.FAILED) free.add(d.id());
            else if (AccessPolicy.check(actor, Action.STOP, s.get().ownerId()).allowed()) mine.add(d.id());
        }
        List<String> names = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());
        var ctx = new TabCompleter.Context(actor.canPlay(), actor.canManageDisplays(), actor.admin(), all, free, mine, names);
        return TabCompleter.complete(ctx, args == null ? new String[0] : Arrays.copyOf(args, args.length));
    }
}
