package dev.des.desecho.plugin;

import dev.des.desecho.core.display.DisplayDefinition;
import dev.des.desecho.core.display.DisplayGeometry;
import dev.des.desecho.core.display.PanelDiff;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.map.MapCanvas;
import org.bukkit.map.MapRenderer;
import org.bukkit.map.MapView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicIntegerArray;

/**
 * One physical screen: a grid of Bukkit maps shown in invisible, fixed, NON-persistent item frames
 * (no blocks are modified; a crash leaves no entities behind). Frames are re-created whenever missing.
 * Rendering: contextual MapRenderers copy a panel from the latest canvas only when that panel's version
 * changed for that player (the server keeps a per-player buffer for contextual maps).
 * MAIN THREAD: ensureFrames, removeFrames, render. ANY THREAD: present, clear.
 */
final class MapSurface {
    private final DisplayDefinition def;
    private final byte blackIndex;
    private final List<Integer> mapIds = new ArrayList<>();
    private final UUID[] frames;
    private final AtomicIntegerArray versions;
    private final List<PanelRenderer> renderers = new ArrayList<>();
    private volatile byte[] canvas;
    private byte[] previous;

    MapSurface(DisplayDefinition def, World world, List<Integer> savedMapIds, byte blackIndex) {
        this.def = def;
        this.blackIndex = blackIndex;
        int n = def.cols() * def.rows();
        this.frames = new UUID[n];
        this.versions = new AtomicIntegerArray(n);
        for (int i = 0; i < n; i++) {
            MapView view = i < savedMapIds.size() ? Bukkit.getMap(savedMapIds.get(i)) : null;
            if (view == null) view = Bukkit.createMap(world);
            for (MapRenderer r : new ArrayList<>(view.getRenderers())) view.removeRenderer(r);
            view.setTrackingPosition(false);
            view.setUnlimitedTracking(false);
            PanelRenderer pr = new PanelRenderer(i);
            view.addRenderer(pr);
            renderers.add(pr);
            mapIds.add(view.getId());
        }
        clear();
    }

    List<Integer> mapIds() { return mapIds; }

    private static BlockFace face(DisplayDefinition.Facing f) {
        return switch (f) { case NORTH -> BlockFace.NORTH; case SOUTH -> BlockFace.SOUTH; case EAST -> BlockFace.EAST; case WEST -> BlockFace.WEST; };
    }

    /** Spawns any missing frames in loaded chunks. Main thread. */
    void ensureFrames() {
        World w = Bukkit.getWorld(UUID.fromString(def.world()));
        if (w == null) return;
        List<DisplayGeometry.Panel> panels = DisplayGeometry.panels(def);
        BlockFace face = face(def.facing());
        for (int i = 0; i < panels.size(); i++) {
            DisplayGeometry.Panel p = panels.get(i);
            // panels() is row-major (row*cols+col), matching map index i
            if (frames[i] != null) {
                Entity e = Bukkit.getEntity(frames[i]);
                if (e != null && e.isValid()) continue;
            }
            if (!w.isChunkLoaded(p.x() >> 4, p.z() >> 4)) continue;
            Location loc = new Location(w, p.x(), p.y(), p.z());
            final int idx = i;
            ItemFrame f = w.spawn(loc, ItemFrame.class, e -> {
                e.setFacingDirection(face, true);
                e.setVisible(false);
                e.setFixed(true);
                e.setPersistent(false);
                e.setInvulnerable(true);
                e.setItemDropChance(0f);
                e.setItem(mapItem(idx), false);
            });
            frames[i] = f.getUniqueId();
        }
    }

    private ItemStack mapItem(int index) {
        ItemStack it = new ItemStack(Material.FILLED_MAP);
        MapMeta mm = (MapMeta) it.getItemMeta();
        mm.setMapView(Bukkit.getMap(mapIds.get(index)));
        it.setItemMeta(mm);
        return it;
    }

    /** Removes every frame entity. Main thread. */
    void removeFrames() {
        for (int i = 0; i < frames.length; i++) {
            if (frames[i] == null) continue;
            Entity e = Bukkit.getEntity(frames[i]);
            if (e != null) e.remove();
            frames[i] = null;
        }
    }

    /** Called from the presenter thread with the display-sized canvas of palette indices (array is reused by the caller). */
    synchronized void present(byte[] c) {
        byte[] copy = c.clone();
        for (PanelDiff.Update u : PanelDiff.diff(previous, copy, def.cols(), def.rows())) {
            versions.incrementAndGet(u.row() * def.cols() + u.col());
        }
        previous = copy;
        canvas = copy;
    }

    synchronized void clear() {
        byte[] black = new byte[def.pixelWidth() * def.pixelHeight()];
        java.util.Arrays.fill(black, blackIndex);
        previous = null;
        canvas = black;
        for (int i = 0; i < versions.length(); i++) versions.incrementAndGet(i);
    }

    void forget(UUID player) { for (PanelRenderer r : renderers) r.seen.remove(player); }

    private final class PanelRenderer extends MapRenderer {
        private final int index;
        private final Map<UUID, Integer> seen = new HashMap<>();

        PanelRenderer(int index) { super(true); this.index = index; }

        @Override
        public void render(MapView map, MapCanvas mc, Player player) {
            int v = versions.get(index);
            Integer last = seen.get(player.getUniqueId());
            if (last != null && last == v) return;
            byte[] c = canvas;
            if (c == null) return;
            int x0 = (index % def.cols()) * 128, y0 = (index / def.cols()) * 128, w = def.pixelWidth();
            for (int y = 0; y < 128; y++) {
                int base = (y0 + y) * w + x0;
                for (int x = 0; x < 128; x++) mc.setPixel(x, y, c[base + x]);
            }
            seen.put(player.getUniqueId(), v);
        }
    }
}
