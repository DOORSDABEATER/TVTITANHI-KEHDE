package dev.des.desecho.plugin;

import dev.des.desecho.core.display.DisplayRegistry;
import dev.des.desecho.core.display.FileDisplayStore;
import dev.des.desecho.core.playback.PlaybackSession;
import dev.des.desecho.core.playback.SessionManager;
import dev.des.desecho.core.provider.DirectMediaProvider;
import dev.des.desecho.core.provider.SourceResolver;
import dev.des.desecho.core.provider.YtDlpProvider;
import dev.des.desecho.core.security.LocalMediaPolicy;
import dev.des.desecho.core.security.UrlGuard;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public final class DesechoPlugin extends JavaPlugin implements Listener {
    private volatile Settings settings;
    private volatile SourceResolver resolver;
    private volatile LocalMediaPolicy localPolicy;
    private DisplayRegistry registry;
    private SessionManager sessions;
    private ScreenManager screens;
    private ExecutorService workers;

    @Override
    public void onEnable() {
        try {
            saveDefaultConfig();
            settings = Settings.from(getConfig());
            buildResolvers();
            registry = new DisplayRegistry(new FileDisplayStore(new File(getDataFolder(), "displays.txt").toPath()));
            registry.loadWarnings().forEach(w -> getLogger().warning(w));
            sessions = new SessionManager(new SessionManager.Limits(settings.maxSessions()), msg -> getLogger().info("[audit] " + msg));
            AtomicInteger n = new AtomicInteger();
            workers = Executors.newFixedThreadPool(4, r -> { Thread t = new Thread(r, "desecho-worker-" + n.incrementAndGet()); t.setDaemon(true); return t; });
            screens = new ScreenManager(this, registry, sessions, () -> settings, workers);
            screens.start();
            DesechoCommand cmd = new DesechoCommand(this, registry, sessions, screens, workers);
            PluginCommand pc = getCommand("desecho");
            if (pc == null) throw new IllegalStateException("command 'desecho' missing from plugin.yml");
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
            getServer().getPluginManager().registerEvents(this, this);
            getLogger().info("DESECHO enabled: " + registry.list().size() + " screen(s) restored. Audio output is NOT implemented in this build.");
        } catch (Exception e) {
            getLogger().log(java.util.logging.Level.SEVERE, "DESECHO failed to start; disabling.", e);
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        try {
            if (sessions != null) {
                List<PlaybackSession> all = sessions.stopAll("plugin disable");
                getLogger().info("Stopped " + all.size() + " playback session(s).");
            }
            if (screens != null) screens.shutdown();
        } catch (RuntimeException e) {
            getLogger().log(java.util.logging.Level.WARNING, "Error during shutdown", e);
        } finally {
            if (workers != null) {
                workers.shutdownNow();
                try { workers.awaitTermination(5, TimeUnit.SECONDS); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            }
        }
    }

    /** (Re)builds URL/local-file resolvers from the current settings. */
    void buildResolvers() throws java.io.IOException {
        Settings s = settings;
        UrlGuard guard = UrlGuard.systemDns(s.allowedPorts());
        Set<String> direct = DirectMediaProvider.DEFAULT_EXTENSIONS;
        resolver = new SourceResolver(guard, List.of(
                new DirectMediaProvider(guard, direct),
                new YtDlpProvider("youtube", Set.of("youtube.com", "youtu.be", "youtube-nocookie.com"), s.ytDlp(), guard, s.extractionTimeoutMs(), s.maxHeight()),
                new YtDlpProvider("twitch", Set.of("twitch.tv"), s.ytDlp(), guard, s.extractionTimeoutMs(), s.maxHeight()),
                new YtDlpProvider("vimeo", Set.of("vimeo.com"), s.ytDlp(), guard, s.extractionTimeoutMs(), s.maxHeight()),
                new YtDlpProvider("generic", Set.of(), s.ytDlp(), guard, s.extractionTimeoutMs(), s.maxHeight())));
        Path dir = new File(getDataFolder(), s.mediaDir()).toPath();
        Files.createDirectories(dir);
        localPolicy = new LocalMediaPolicy(List.of(dir), s.localExtensions());
    }

    void reloadSettings() throws java.io.IOException {
        reloadConfig();
        settings = Settings.from(getConfig());
        buildResolvers();
    }

    Settings settings() { return settings; }
    SourceResolver resolver() { return resolver; }
    LocalMediaPolicy localPolicy() { return localPolicy; }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        if (screens != null) screens.forgetPlayer(e.getPlayer().getUniqueId());
    }
}
