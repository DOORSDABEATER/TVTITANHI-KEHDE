package dev.des.desecho.plugin;

import dev.des.desecho.core.display.DisplayDefinition;
import dev.des.desecho.core.display.DisplayGeometry;
import dev.des.desecho.core.display.DisplayRegistry;
import dev.des.desecho.core.display.PaletteQuantizer;
import dev.des.desecho.core.engine.DisplaySink;
import dev.des.desecho.core.engine.ScreenPlayer;
import dev.des.desecho.core.media.FfmpegCommands;
import dev.des.desecho.core.playback.FailureStage;
import dev.des.desecho.core.playback.PlaybackSession;
import dev.des.desecho.core.playback.SessionManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.map.MapPalette;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.function.Supplier;

/** Runtime state for every screen: map surfaces, running players, viewer sets. Main-thread API unless noted. */
final class ScreenManager {
    private final DesechoPlugin plugin;
    private final DisplayRegistry registry;
    private final SessionManager sessions;
    private final Supplier<Settings> settings;
    private final ExecutorService workers;
    private final PaletteQuantizer quantizer;
    private final byte black;
    private final Map<String, MapSurface> surfaces = new ConcurrentHashMap<>();
    private final Map<String, ScreenPlayer> players = new ConcurrentHashMap<>();
    private final Map<String, Set<UUID>> viewers = new ConcurrentHashMap<>();
    private final File mapIdFile;
    private final List<BukkitTask> tasks = new ArrayList<>();

    ScreenManager(DesechoPlugin plugin, DisplayRegistry registry, SessionManager sessions, Supplier<Settings> settings, ExecutorService workers) {
        this.plugin = plugin;
        this.registry = registry;
        this.sessions = sessions;
        this.settings = settings;
        this.workers = workers;
        this.mapIdFile = new File(plugin.getDataFolder(), "mapids.yml");
        int[] argb = new int[256];
        for (int i = 0; i < 256; i++) {
            try { argb[i] = MapPalette.getColor((byte) i).getRGB(); } catch (RuntimeException e) { argb[i] = 0; }
        }
        this.quantizer = new PaletteQuantizer(argb, 4);
        this.black = quantizer.indexOf(0, 0, 0);
    }

    /** Creates surfaces for every registered screen and starts the periodic tasks. */
    void start() {
        for (DisplayDefinition d : registry.list()) {
            try { addScreen(d); } catch (RuntimeException e) { plugin.getLogger().warning("Could not restore screen '" + d.id() + "': " + e.getMessage()); }
        }
        tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, this::trackViewers, 20L, 10L));
        tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, this::maintain, 40L, 100L));
    }

    void addScreen(DisplayDefinition d) {
        World w = Bukkit.getWorld(UUID.fromString(d.world()));
        if (w == null) throw new IllegalStateException("world is not loaded");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(mapIdFile);
        List<Integer> saved = y.getIntegerList(d.id());
        MapSurface s = new MapSurface(d, w, saved, black);
        if (!s.mapIds().equals(saved)) {
            y.set(d.id(), s.mapIds());
            try { y.save(mapIdFile); } catch (IOException e) { plugin.getLogger().warning("Could not save map ids: " + e.getMessage()); }
        }
        surfaces.put(d.id(), s);
        s.ensureFrames();
    }

    void removeScreen(String id) {
        release(id);
        MapSurface s = surfaces.remove(id);
        if (s != null) s.removeFrames();
        viewers.remove(id);
    }

    boolean hasSurface(String id) { return surfaces.containsKey(id); }

    void startPlayback(PlaybackSession s, DisplayDefinition d, FfmpegCommands.Source src) {
        MapSurface surf = surfaces.get(d.id());
        if (surf == null) {
            sessions.fail(s, FailureStage.DISPLAY, "That screen isn't available right now (its world may not be loaded).");
            return;
        }
        Settings st = settings.get();
        var plan = st.preset().plan(d.pixelWidth(), d.pixelHeight(), st.maxFps());
        var cfg = new ScreenPlayer.Config(st.ffmpeg(), d.pixelWidth(), d.pixelHeight(), plan, st.maxStreamSeconds(), 16, st.idleGraceMs());
        DisplaySink sink = new DisplaySink() {
            @Override public void present(byte[] c) { surf.present(c); }
            @Override public void clear() { surf.clear(); }
        };
        String id = d.id();
        ScreenPlayer p = new ScreenPlayer(sessions, s, src, cfg, quantizer, sink, () -> !viewers.getOrDefault(id, Set.of()).isEmpty());
        ScreenPlayer old = players.put(id, p);
        if (old != null) workers.submit(old::close);
        p.start();
    }

    /** Stops the picture pipeline for a screen without ever blocking the server thread. */
    void release(String id) {
        ScreenPlayer p = players.remove(id);
        if (p != null) workers.submit(p::close);
    }

    boolean isActive(String id) { ScreenPlayer p = players.get(id); return p != null && p.isRunning(); }

    void forgetPlayer(UUID uuid) { for (MapSurface s : surfaces.values()) s.forget(uuid); }

    private void trackViewers() {
        for (DisplayDefinition d : registry.list()) {
            World w = Bukkit.getWorld(UUID.fromString(d.world()));
            if (w == null) continue;
            Set<UUID> set = new HashSet<>();
            for (Player pl : w.getPlayers()) {
                Location l = pl.getLocation();
                if (DisplayGeometry.distanceToCenter(d, l.getX(), l.getY(), l.getZ()) <= d.viewDistance()) set.add(pl.getUniqueId());
            }
            viewers.put(d.id(), Set.copyOf(set));
        }
    }

    private void maintain() {
        for (MapSurface s : surfaces.values()) s.ensureFrames();
        for (Map.Entry<String, ScreenPlayer> e : players.entrySet()) {
            if (!e.getValue().isRunning() && players.remove(e.getKey(), e.getValue())) workers.submit(e.getValue()::close);
        }
    }

    int activePlayers() { return (int) players.values().stream().filter(ScreenPlayer::isRunning).count(); }

    /** Shutdown: stop tasks, close every player synchronously, remove every frame. */
    void shutdown() {
        for (BukkitTask t : tasks) t.cancel();
        for (ScreenPlayer p : players.values()) p.close();
        players.clear();
        for (MapSurface s : surfaces.values()) s.removeFrames();
        surfaces.clear();
    }
}
