package dev.des.desecho.plugin;

import dev.des.desecho.core.permission.Actor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** Every decision is made from server-side permission checks at the moment of the command. */
final class ActorFactory {
    private ActorFactory() {}

    static Actor of(CommandSender s) {
        if (!(s instanceof Player p)) return Actor.console();
        boolean admin = p.isOp() || p.hasPermission("desecho.admin");
        return new Actor(p.getUniqueId(), p.getName(), p.hasPermission("desecho.play"), p.hasPermission("desecho.display.manage"), admin);
    }
}
