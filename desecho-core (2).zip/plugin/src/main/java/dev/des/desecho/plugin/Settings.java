package dev.des.desecho.plugin;

import dev.des.desecho.core.media.QualityPreset;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

record Settings(String ffmpeg, String ytDlp, String mediaDir, Set<String> localExtensions, QualityPreset preset, int maxFps,
                int maxSessions, int maxStreamSeconds, long extractionTimeoutMs, int maxHeight, long idleGraceMs,
                Set<Integer> allowedPorts, long rateLimitMs, double defaultAudioRange, double defaultViewDistance,
                int maxCols, int maxRows) {
    static Settings from(FileConfiguration c) {
        QualityPreset preset;
        try { preset = QualityPreset.valueOf(c.getString("quality-preset", "BALANCED").toUpperCase()); }
        catch (IllegalArgumentException e) { preset = QualityPreset.BALANCED; }
        Set<Integer> ports = new HashSet<>(c.getIntegerList("allowed-ports"));
        if (ports.isEmpty()) ports = Set.of(80, 443);
        List<String> ext = c.getStringList("local-extensions");
        return new Settings(c.getString("ffmpeg-path", "ffmpeg"), c.getString("yt-dlp-path", "yt-dlp"),
                c.getString("media-directory", "media"), ext.isEmpty() ? Set.of("mp4") : new HashSet<>(ext), preset,
                Math.max(1, c.getInt("max-fps", 20)), Math.max(1, c.getInt("max-active-sessions", 4)),
                Math.max(10, c.getInt("max-stream-seconds", 14400)), Math.max(1, c.getInt("extraction-timeout-seconds", 20)) * 1000L,
                Math.max(144, c.getInt("max-extraction-height", 720)), Math.max(1, c.getInt("idle-grace-seconds", 5)) * 1000L,
                ports, Math.max(0, c.getInt("url-rate-limit-seconds", 5)) * 1000L,
                c.getDouble("default-audio-range", 32), c.getDouble("default-view-distance", 48),
                Math.max(1, c.getInt("max-screen-cols", 16)), Math.max(1, c.getInt("max-screen-rows", 9)));
    }
}
