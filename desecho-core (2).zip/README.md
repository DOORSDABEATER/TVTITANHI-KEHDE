# DESECHO - core engine (tested) + Paper plugin DRAFT (uncompiled, see docs/PLUGIN_DRAFT.md)

**This is NOT a plugin yet.** There is no Paper JAR, no Plasmo Voice integration, no map-packet display, no
YouTube/Twitch/Vimeo providers, no persistence, no commands. None of the 30 acceptance tests in the spec have
been run in a Minecraft server; **all 30 are still OPEN**. See `docs/IMPLEMENTATION_PLAN.md` for the plan, blockers and per-item status.

What exists is `core/`: the pure-Java engine pieces that do not depend on Paper, so they could be compiled
and tested for real in the sandbox this was built in (JDK 21, ffmpeg 6.1.1, no network, no Paper/Plasmo jars).

## What is implemented and verified (122 unit + 42 engine integration + 103 registry/command/provider checks; logs: `test-run.txt`, `integration-run.txt`, `phase2-run.txt`)
| Module | What it does | Verified by |
|---|---|---|
| `permission` | Owner / OP / display-manage rules, UUID identity only | unit checks of the policy |
| `playback.SessionManager` | One session per screen, ownership on every op, admin override + transfer, audit log, limits, atomic start (32-thread race = 1 winner), shutdown `stopAll` | unit checks |
| `playback.PlaybackClock` | Single clock: start/pause/resume/seek | unit checks with fake time |
| `security.UrlGuard` | SSRF: http/https only, no creds, port allow-list, every resolved IP must be public (v4, v6, mapped, NAT64, 6to4) | 30+ URL cases |
| `security.LocalMediaPolicy` | Approved dirs only, no abs paths / `..` / symlink escape, one generic error | temp-dir tests |
| `media.FfmpegCommands` | Argument lists (no shell), protocol whitelist before `-i`, letterbox inside ffmpeg, fps/scale/duration/seek | run against real ffmpeg |
| `media.FfmpegVideoDecoder` | Managed process, bounded queue, backpressure, error capture, `close()` kills process and threads | run against real ffmpeg |
| `media.FramePacer/FrameQueue` | Clock-driven frame choice, stale frames dropped, bounded | unit checks |
| `display.PanelDiff` | Per-map partial updates (changed rectangle only) | unit checks |
| `display.PaletteQuantizer` | RGB -> map palette via LUT; palette is supplied at runtime, never hard-coded | unit checks |
| `engine.ScreenPlayer` | Decoder -> queue -> clock-paced presenter -> `DisplaySink`; pause/seek/stop, idle decoder shutdown when nobody watches, resync on return, EOF/error handling, failure isolation | integration tests, real ffmpeg |
| `engine.AudioFeeder` | 20 ms PCM frames paced against the same clock; pause/seek/idle handling; surfaces 'no audio track' | integration tests, real ffmpeg |
| `display.DisplayRegistry/FileDisplayStore/DisplayGeometry` | Screen definitions, panel layout per facing, overlap check, atomic persistence + restart restore | unit checks |
| `command.ArgParsers/TabCompleter` | Time/volume/facing/id validation, permission-aware tab completion | unit checks |
| `provider.*` | Direct + yt-dlp providers, resolver chain, JSON parser; SSRF re-check, timeouts, size caps | fake yt-dlp scripts only; no real site tested |
| `media.QualityPreset` | Presets -> decode size/upscale/fps for a given display | unit checks |

Build/test here: `java -m jdk.compiler/com.sun.tools.javac.Main -d out $(find core -name '*.java')` then run `dev.des.desecho.core.TestMain`, `...IntegrationTests` and `...Phase2Tests` with `java -cp out` (needs `ffmpeg` on PATH; integration run takes ~40 s)

## Design decisions worth knowing
* **Clock-paced pipeline.** ffmpeg decodes ahead into a small bounded queue (backpressure stalls it); the presenter asks
  the session clock "what frame is due?" and drops the rest. Audio will be a second ffmpeg process started at the same offset
  against the same clock. A seek bumps `seekEpoch`; the engine restarts both decoders.
* **Map displays are a bandwidth problem, not a decoder problem.** A map is 128x128 bytes. 1920x1080 would be ~2 MB per frame
  per viewer before compression (~40 MB/s at 20 fps). The 1080p/1440p/4K presets are therefore decode caps only; real quality is
  set by screen size (maps x 128). `PanelDiff` helps for static-ish scenes, not for full-motion video. Realistic FPS per
  screen size must be measured on your server in Phase 2.
* **Palette is read from the running server**, so the Paper layer builds `PaletteQuantizer` from the server's own map palette.

## Known limitations / not done
* Not tested on Paper, not tested with Plasmo Voice, not tested with real players (acceptance 2, 6-15, 21-23, 27-29 need a server).
* `UrlGuard` is check-then-use: DNS rebinding between validation and ffmpeg's own connect is not closed. Redirect hops and
  provider-returned URLs must each go through `validate()` (provider layer not written yet).
* Local media directories must contain only trusted files (ffmpeg detects format by content, not extension).
* No playback speed control. Seek restarts the decoder (not instant). Video rotation metadata is handled by ffmpeg autorotate (untested).
* Audio command emits 48 kHz mono s16le; that this matches Plasmo Voice's source API is unverified until Phase 3.
* Quantize time measured in the sandbox: ~1.2 ms for a 1024x512 frame. Your server's number will differ.

## Engine behaviours worth knowing
* If nobody is in range when a video starts, decoding does not start; it begins (from 0) when the first viewer arrives. Once playing, the clock keeps running with no viewers and late/returning viewers resync to it.
* Decoder falling behind real time is handled by dropping frames, not by slowing the clock; there is no catch-up seek.
* Audio start-up allowance is 300 ms; frames more than 200 ms late are dropped.

## Next steps (in order)
1. **Phase 1 for real:** run `scripts/audit-environment.sh` on the server, send back `desecho-audit.txt` plus `/version` and `/plugins` output.
   Dependency versions (Paper API for 26.x, Plasmo Voice API) are chosen only after that; they were not available offline here.
2. Phase 2: Paper plugin shell, map-packet display for one screen, `/desecho play` for direct MP4, owner/OP wired to real permissions.
3. Phase 3: Plasmo Voice addon, then the acceptance tests run and recorded honestly.
