# DESECHO plugin layer - UNCOMPILED, UNTESTED DRAFT (video only, no audio)

Status: written from memory of the Bukkit/Paper API. It has NEVER been compiled against Paper, never loaded, never run.
Expect compile errors on the first build; send them back and they get fixed. There is no JAR in this package.

## Build (on a machine with JDK 25 + Gradle)
1. Edit `plugin/gradle.properties`: set `paperApi` (Paper API version of your server build), `apiVersion`, `javaVersion`.
2. `cd plugin && gradle build`  ->  `plugin/build/libs/DESECHO.jar` (core is compiled into it).
3. Copy the jar to `plugins/`, install `ffmpeg` on the server (and `yt-dlp` for site links), restart.

## Try it
* Put a small `clip.mp4` in `plugins/DESECHO/media/`.
* Stand in front of a flat wall, look at the wall block that should be the screen's bottom-left: `/desecho create test 4 3`
  (needs a solid wall behind every panel and free air in front; grows right and up).
* `/desecho play test file:clip.mp4`  or  `/desecho play test https://host/video.mp4`
* `/desecho pause test`, `resume`, `seek test 0:30`, `stop test`, `info test`, `screens`, `diagnostics`, `status`.
* Permissions (default OP): `desecho.play`, `desecho.display.manage`, `desecho.admin`.

## Known gaps / unverified
* **No audio.** Plasmo Voice is not integrated (its API could not be checked offline). `volume`/`mute` only store state.
* Map rendering runs on the main thread inside contextual `MapRenderer.render` (one full-panel copy per changed panel per player); big screens may cost TPS. Needs measuring.
* Frames are item frames spawned as non-persistent entities, re-created every 5 s if missing; behaviour in unloaded chunks, with other plugins, and on Paper 26.x is unverified.
* YouTube/Twitch/Vimeo: needs yt-dlp installed; never tested against a real site.
* Playback is not resumed after restart (by design); screens and their map ids are restored.
