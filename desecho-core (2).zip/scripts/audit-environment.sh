#!/usr/bin/env bash
# DESECHO Phase 1 environment audit. Run from the Minecraft server directory (the one containing plugins/).
# Read-only. Writes desecho-audit.txt. Prints only whitelisted server.properties keys (no passwords).
OUT=desecho-audit.txt
{
echo "== DESECHO environment audit $(date -u +%FT%TZ) =="
echo; echo "-- Java"; java -version 2>&1 | head -3
echo; echo "-- Server jar(s) in this folder"; ls -1 ./*.jar 2>/dev/null
[ -f version_history.json ] && { echo "version_history.json:"; cat version_history.json; echo; }
echo; echo "-- Plugins (name / version / api-version from each jar)"
for j in plugins/*.jar; do
  [ -e "$j" ] || continue
  echo "* $(basename "$j")"
  for y in paper-plugin.yml plugin.yml; do
    unzip -p "$j" "$y" 2>/dev/null | grep -E '^(name|version|api-version|main):' | sed 's/^/    /'
  done
done
echo; echo "-- Plasmo Voice files"; ls -1 plugins | grep -i plasmo; ls -1 plugins/PlasmoVoice 2>/dev/null
echo; echo "-- server.properties (selected keys)"
grep -E '^(resource-pack|resource-pack-sha1|require-resource-pack|network-compression-threshold|view-distance|simulation-distance|online-mode|max-players)=' server.properties 2>/dev/null
echo; echo "-- Hardware"; echo "cpus: $(nproc)"; free -m 2>/dev/null | head -2; df -h . | tail -1
echo; echo "-- Media tools"
for t in ffmpeg ffprobe yt-dlp; do
  if command -v $t >/dev/null; then echo "$t: $($t -version 2>&1 | head -1 || true) $($t --version 2>&1 | head -1)"; else echo "$t: NOT FOUND"; fi
done
echo; echo "-- Existing music/media plugins (name match)"; ls -1 plugins | grep -iE 'music|jukebox|note|audio|cinema|video|map|image'
echo; echo "Also paste the in-game output of:  /version   and   /plugins"
} 2>&1 | tee "$OUT"
echo; echo "Saved to $OUT"
